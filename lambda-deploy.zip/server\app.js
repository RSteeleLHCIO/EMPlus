import "dotenv/config";
import express from "express";
import cors from "cors";
import multer from "multer";
import { parse } from "csv-parse/sync";
import XLSX from "xlsx";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { randomBytes } from "crypto";
import { normalizeDateInput } from "./dateUtils.js";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import {
  getNode,
  putNode,
  deleteNode,
  queryNodes,
  putNodeHistory,
  deleteNodeHistory,
  queryNodeHistoryForNode,
  nodeHasHistory,
  forEachNodeHistoryPage,
  getRel,
  putRel,
  deleteRel,
  queryRels,
  queryRelsByFrom,
  queryRelsByTo,
  putOwnershipCurrent,
  deleteOwnershipCurrent,
  queryOwnershipCurrent,
  putOwnershipHistory,
  queryOwnershipHistory,
  deleteOwnershipHistory,
  batchPutOwnershipHistory,
  makeRelKey,
  getDDField,
  putDDField,
  deleteDDField,
  queryDDFields,
  getExportReport,
  putExportReport,
  deleteExportReport,
  queryExportReports,
  getClient,
  putClient,
} from "./dynamoClient.js";
import {
  getUser,
  putUser,
  listUsersByClient,
  countUsersByClient,
} from "./authClient.js";

const JWT_SECRET = process.env.JWT_SECRET || "changeme-set-JWT_SECRET-env-var";
const JWT_EXPIRY = process.env.JWT_EXPIRY || "8h";
const SETUP_SECRET = process.env.SETUP_SECRET || null;

// ─── Pure business-logic helpers (no DynamoDB concerns) ──────────────────────

const normalizeEmails = (value) => {
  if (!value) return [];
  if (Array.isArray(value)) {
    return value.map((item) => String(item || "").trim()).filter(Boolean);
  }
  if (typeof value === "string") {
    return value.split(/[,;]+/).map((item) => item.trim()).filter(Boolean);
  }
  return [String(value).trim()].filter(Boolean);
};

const slugify = (value) =>
  String(value || "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

const normalizeClientId = (client, rawId) => {
  if (!rawId) return rawId;
  if (!client) return rawId;
  const trimmed = String(rawId).trim();
  if (trimmed.includes("|")) return trimmed;
  return `${client}|${trimmed}`;
};

const detectHeaderRow = (row) => {
  if (!Array.isArray(row)) return false;
  const headers = row.map((cell) => String(cell || "").trim().toLowerCase());
  return headers.some((header) =>
    [
      "name",
      "node",
      "node name",
      "kind",
      "type",
      "owner",
      "owned",
      "entity",
      "percent",
      "percentage",
      "pct",
      "from",
      "to",
      "parent",
      "child",
      "source",
      "target",
    ].includes(header)
  );
};

const getColumnIndex = (headers, candidates, fallback) => {
  const lowered = headers.map((header) => String(header || "").trim().toLowerCase());
  const found = candidates.findIndex((candidate) => lowered.includes(candidate));
  if (found !== -1) return lowered.indexOf(candidates[found]);
  return fallback;
};

// ─── Fuzzy header → DD field mapping ─────────────────────────────────────────

// Maps known user column header variants to canonical DD field names.
const FIELD_SYNONYMS = {
  // NOTE: "kind" is intentionally absent — the details upload must never alter a node's kind.
  name:            ["name", "company name", "entity name", "node name", "organization", "org name", "business name", "legal name", "entity or person s name"],
  address:         ["address", "street", "street address", "mailing address", "location", "addr"],
  workPhone:       ["work phone", "phone", "workphone", "office phone", "ph work", "business phone", "telephone", "tel", "phone number", "primary phone"],
  cellPhone:       ["cell phone", "cell", "mobile", "mobile phone", "cellphone", "cell number", "personal phone"],
  emails:          ["email", "emails", "email address", "e mail", "email addr"],
  taxId:           ["tax id", "taxid", "ein", "tin", "federal id", "tax identification", "federal tax id", "fein"],
  accountingUrl:   ["accounting url", "accounting", "accountingurl", "acctg link", "quickbooks url", "quickbooks", "accounting link", "acctg url"],
  hrUrl:           ["hr url", "hrurl", "hr link", "hr system", "hris url", "hris", "human resources url"],
  logo:            ["logo", "logo url", "logo link", "company logo"],
  photo:           ["photo", "photo url", "picture", "headshot", "profile photo", "image"],
  legalStatus:     ["legal status", "legalstatus", "entity structure", "structure", "corp type", "company type", "incorporation type"],
  operationalRole: ["operational role", "operationalrole", "role", "function", "operational function", "business role"],
  personStatus:    ["person status", "personstatus", "status", "employment status"],
  notes:           ["notes", "note", "comments", "comment", "memo", "remarks"],
};

// Strips punctuation, lowercases, and collapses whitespace in a header string.
const normalizeHeader = (str) =>
  String(str || "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();

// Jaccard token-overlap score between two normalized strings.
const tokenOverlap = (a, b) => {
  const ta = new Set(a.split(" ").filter(Boolean));
  const tb = new Set(b.split(" ").filter(Boolean));
  if (ta.size === 0 && tb.size === 0) return 0;
  const intersection = [...ta].filter((t) => tb.has(t)).length;
  const union = new Set([...ta, ...tb]).size;
  return intersection / union;
};

// Maps an array of raw column headers to DD field names.
// Returns:
//   fieldMap — { columnIndex: { field, confidence: "exact"|"fuzzy" } }
//   guessed  — { rawHeader: fieldName } for fuzzy-matched columns (surfaced as warnings)
//   extra    — rawHeaders with no DD match (will be stored in customFields)
const mapHeadersToFields = (headers, ddPromptsSet = new Set()) => {
  const fieldMap = {};
  const guessed = {};
  const extra = [];

  headers.forEach((rawHeader, idx) => {
    const normalized = normalizeHeader(rawHeader);
    if (!normalized) return; // skip blank column headers

    // First pass: exact match against DD field prompts.
    // If the header matches a known DD field, treat it as a DD (extra) field
    // immediately — do not attempt any built-in synonym matching.
    if (ddPromptsSet.has(normalized)) {
      extra.push(rawHeader);
      return;
    }
    // Second pass: built-in synonym matching (exact, then fuzzy with extra-token guard).
    let matched = null;
    for (const [field, synonyms] of Object.entries(FIELD_SYNONYMS)) {
      if (synonyms.includes(normalized)) {
        matched = { field, confidence: "exact" };
        break;
      }
    }

    // Fuzzy fallback: best token-overlap score ≥ 0.5, but only if the header has
    // at most 1 token not covered by the synonym.  This prevents descriptive names
    // like "Franchise & Excise Tax ID" (4 tokens, 2 unmatched) from hijacking
    // short synonyms like "tax id" (2 tokens).
    if (!matched) {
      let bestScore = 0;
      let bestField = null;
      for (const [field, synonyms] of Object.entries(FIELD_SYNONYMS)) {
        for (const synonym of synonyms) {
          const ta = new Set(normalized.split(" ").filter(Boolean));
          const tb = new Set(synonym.split(" ").filter(Boolean));
          const intersectionCount = [...ta].filter((t) => tb.has(t)).length;
          const unionCount = new Set([...ta, ...tb]).size;
          const score = unionCount === 0 ? 0 : intersectionCount / unionCount;
          const unmatchedHeaderTokens = ta.size - intersectionCount;
          if (score > bestScore && unmatchedHeaderTokens <= 1) {
            bestScore = score;
            bestField = field;
          }
        }
      }
      if (bestScore >= 0.5) matched = { field: bestField, confidence: "fuzzy" };
    }

    if (matched) {
      fieldMap[idx] = matched;
      if (matched.confidence === "fuzzy") guessed[rawHeader] = matched.field;
    } else {
      extra.push(rawHeader);
    }
  });

  return { fieldMap, guessed, extra };
};

const parseNodeCsv = (csvText, defaultKind = "entity", client) => {
  if (!csvText || typeof csvText !== "string") return { rows: [], skipped: 0 };
  const records = parse(csvText, {
    skip_empty_lines: true,
    relax_column_count: true,
    trim: true,
  });
  if (!Array.isArray(records) || records.length === 0) return { rows: [], skipped: 0 };

  let startIndex = 0;
  let nameIndex = 0;
  let kindIndex = 1;
  if (detectHeaderRow(records[0])) {
    const headers = records[0];
    nameIndex = getColumnIndex(headers, ["name", "node", "node name"], 0);
    kindIndex = getColumnIndex(headers, ["kind", "type"], 1);
    startIndex = 1;
  }

  const rows = [];
  let skipped = 0;
  for (let i = startIndex; i < records.length; i += 1) {
    const record = records[i] || [];
    const rawName = record[nameIndex] ?? record[0];
    const rawKind = record[kindIndex] ?? record[1];
    const name = String(rawName || "").trim();
    if (!name) {
      skipped += 1;
      continue;
    }
    const kindValue = String(rawKind || defaultKind || "entity").trim();
    const kind = /person/i.test(kindValue) ? "person" : "entity";
    const slug = slugify(name) || "node";
    const rawId = `${kind}:${slug}`;
    rows.push({ id: normalizeClientId(client, rawId), name, kind });
  }

  return { rows, skipped };
};

const parseOwnershipCsv = (csvText) => {
  if (!csvText || typeof csvText !== "string") return { rows: [], skipped: 0 };
  const records = parse(csvText, {
    skip_empty_lines: true,
    relax_column_count: true,
    trim: true,
  });
  if (!Array.isArray(records) || records.length === 0) return { rows: [], skipped: 0 };

  let startIndex = 0;
  let ownerIndex = 0;
  let ownedIndex = 1;
  let percentIndex = 2;
  if (detectHeaderRow(records[0])) {
    const headers = records[0];
    ownerIndex = getColumnIndex(headers, ["owner", "from", "parent", "source"], 0);
    ownedIndex = getColumnIndex(headers, ["owned", "entity", "to", "child", "target"], 1);
    percentIndex = getColumnIndex(headers, ["percent", "percentage", "pct"], 2);
    startIndex = 1;
  }

  const rows = [];
  let skipped = 0;
  for (let i = startIndex; i < records.length; i += 1) {
    const record = records[i] || [];
    const rawOwner = record[ownerIndex] ?? record[0];
    const rawOwned = record[ownedIndex] ?? record[1];
    const rawPercent = record[percentIndex] ?? record[2];
    const owner = String(rawOwner || "").trim();
    const owned = String(rawOwned || "").trim();
    if (!owner || !owned) {
      skipped += 1;
      continue;
    }
    const percentText = String(rawPercent ?? "").trim();
    const percent = percentText === "" ? Number.NaN : Number(percentText);
    const startDateRaw = record[getColumnIndex(records[0] ?? [], ["start", "start date", "startdate", "effective"], -1)] ?? "";
    const endDateRaw   = record[getColumnIndex(records[0] ?? [], ["end",   "end date",   "enddate",   "expiry"],    -1)] ?? "";
    rows.push({
      owner, owned, percent,
      startDate: normalizeDateInput(startDateRaw) || null,
      endDate:   normalizeDateInput(endDateRaw)   || null,
    });
  }

  return { rows, skipped };
};

// ─── Node details CSV/XLSX parser ────────────────────────────────────────────

// Converts a parsed records array (header row + data rows) into patch objects.
// Each row produces { name, patch } where patch contains only fields present in the file.
// Columns that don't match any DD field are stored under customFields.
const parseRecordsToDetailRows = (records, ddPromptsSet = new Set()) => {
  if (!Array.isArray(records) || records.length < 2) return { rows: [], mapping: {}, skipped: 0 };

  const headers = records[0].map((h) => String(h ?? ""));
  const { fieldMap, guessed, extra } = mapHeadersToFields(headers, ddPromptsSet);

  // A "name" column is required to identify each node.
  const nameColIdx = Number(
    Object.entries(fieldMap).find(([, v]) => v.field === "name")?.[0] ?? -1
  );
  if (nameColIdx === -1) {
    throw Object.assign(new Error('CSV must contain a "name" column to identify nodes'), { status: 400 });
  }

  // Map column indices for unrecognised headers → stored in customFields.
  const extraColMap = {};
  headers.forEach((rawHeader, idx) => {
    if (extra.includes(rawHeader) && rawHeader.trim()) extraColMap[idx] = rawHeader.trim();
  });

  const rows = [];
  let skipped = 0;
  for (let i = 1; i < records.length; i++) {
    const record = records[i] || [];
    const name = String(record[nameColIdx] ?? "").trim();
    if (!name || name.startsWith("[")) { skipped += 1; continue; }

    const patch = {};
    for (const [idxStr, { field }] of Object.entries(fieldMap)) {
      if (field === "name") continue;
      const value = String(record[Number(idxStr)] ?? "").trim();
      if (value !== "") patch[field] = value;
    }

    // Non-DD columns stored separately so applyDetailRows can assign proper DD fieldIds.
    const extraValues = {};
    for (const [idxStr, header] of Object.entries(extraColMap)) {
      const value = String(record[Number(idxStr)] ?? "").trim();
      if (value !== "") extraValues[header] = value;
    }

    rows.push({ name, patch, extraValues });
  }

  return { rows, extraHeaders: extra, mapping: { guessed, extra }, skipped };
};

const parseDetailsCsv = (csvText, ddPromptsSet = new Set()) => {
  if (!csvText || typeof csvText !== "string") return { rows: [], mapping: {}, skipped: 0 };
  const records = parse(csvText, { skip_empty_lines: true, relax_column_count: true, trim: true });
  return parseRecordsToDetailRows(records, ddPromptsSet);
};

const parseDetailsXlsx = (buffer, ddPromptsSet = new Set()) => {
  const workbook = XLSX.read(buffer, { type: "buffer" });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const records = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });
  return parseRecordsToDetailRows(records, ddPromptsSet);
};

const xlsxBufferToCsv = (buffer) => {
  const workbook = XLSX.read(buffer, { type: "buffer" });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  return XLSX.utils.sheet_to_csv(sheet);
};

// ─── DynamoDB item builders ───────────────────────────────────────────────────

const buildNodeItem = (
  { id, name, kind, client, address, workPhone, cellPhone, emails, photo,
    taxId, accountingUrl, hrUrl, logo, customFields,
    operationalRole, legalStatus, personStatus, notes,
    createdAt, updatedAt }
) => ({
  clientId: client,
  nodeId: id,          // DynamoDB sort key — mirrors id
  id,                  // returned to frontend
  name,
  kind,
  client,
  address: address || "",
  workPhone: workPhone || "",
  cellPhone: cellPhone || "",
  emails: normalizeEmails(emails),
  photo: photo || "",
  taxId: taxId || "",
  accountingUrl: accountingUrl || "",
  hrUrl: hrUrl || "",
  logo: logo || "",
  operationalRole: operationalRole || "",
  legalStatus: legalStatus || "",
  personStatus: personStatus || "",
  notes: notes || "",
  customFields: customFields || {},
  createdAt,
  updatedAt,
});

const makeNodeHistoryKey = ({ nodeId, effectiveFrom, versionId }) =>
  `NODE#${nodeId}#AT#${effectiveFrom}#VER#${versionId}`;

const isNodeActiveAt = (row, asOf) => {
  const start = row.effectiveFrom || "0001-01-01";
  const end = row.effectiveTo || "9999-12-31";
  return start <= asOf && end > asOf;
};

const listNodeRows = async (clientId, asOf = null) => {
  const targetAsOf = asOf || null;
  if (targetAsOf) {
    try {
      // History is reduced page by page, keeping only the winning row per node, so memory
      // scales with the number of nodes rather than with total accumulated history.
      // Winner: the active, non-deleted row with the latest effectiveFrom (first seen wins ties).
      const byNodeId = new Map();
      const historyNodeIds = new Set();
      const [currentRows] = await Promise.all([
        queryNodes(clientId),
        forEachNodeHistoryPage(clientId, (page) => {
          page.forEach((row) => {
            if (!row.nodeId) return;
            historyNodeIds.add(row.nodeId);
            if (row.deleted || !isNodeActiveAt(row, targetAsOf)) return;
            const existing = byNodeId.get(row.nodeId);
            const start = row.effectiveFrom || "0001-01-01";
            if (!existing || start > (existing.effectiveFrom || "0001-01-01")) {
              byNodeId.set(row.nodeId, row);
            }
          });
        }),
      ]);

      // Nodes with zero history rows predate version tracking (e.g. legacy/imported
      // data that never went through persistNodeVersion). With no record of them ever
      // being different, assume they've always existed and include their current data.
      currentRows.forEach((node) => {
        const id = node.id || node.nodeId;
        if (id && !historyNodeIds.has(id) && !byNodeId.has(id)) {
          byNodeId.set(id, node);
        }
      });

      if (byNodeId.size > 0) return [...byNodeId.values()];
    } catch (err) {
      console.warn("listNodeRows: history query failed, falling back to current nodes:", err.message);
    }
  }
  return queryNodes(clientId);
};

// Recorded/audit-date mode: reconstruct what a live query of the system would have
// shown at a real wall-clock instant, ignoring business effective dating entirely.
// Selects, per node, the most recently *written* version whose changedAt is at or
// before the cutoff — but only among versions that were ever the live "current" record
// (wasCurrent !== false; legacy rows predating this field default to eligible).
const listNodeRowsRecorded = async (clientId, cutoffIso) => {
  const latestByNodeId = new Map();
  const historyNodeIds = new Set();
  const [currentRows] = await Promise.all([
    queryNodes(clientId),
    forEachNodeHistoryPage(clientId, (page) => {
      page.forEach((row) => {
        if (!row.nodeId) return;
        historyNodeIds.add(row.nodeId);
        if (row.wasCurrent === false || !row.changedAt || row.changedAt > cutoffIso) return;
        const existing = latestByNodeId.get(row.nodeId);
        if (!existing || row.changedAt > existing.changedAt) latestByNodeId.set(row.nodeId, row);
      });
    }),
  ]);

  const results = [];
  latestByNodeId.forEach((row) => {
    if (!row.deleted) results.push(row);
  });

  // Nodes with zero history rows at all predate version tracking — assume always existed.
  currentRows.forEach((node) => {
    const id = node.id || node.nodeId;
    if (id && !historyNodeIds.has(id)) results.push(node);
  });
  return results;
};

// `replaceSameStart` controls what happens when a save's effective date collides with an
// existing history row for the same node:
//  - true (default): replace it — this is the original "correct a backdated entry" behavior,
//    still used where a caller may intentionally pick an explicit effective date (e.g. CSV
//    node imports/corrections).
//  - false: keep it — used for plain entity field edits, where every save is now recorded as
//    effective from the entity's creation date by policy, so collisions are the norm rather
//    than a correction. Keeping prior rows (and letting the "close any still-open row" step
//    below mark them superseded) preserves the full per-edit audit trail (who/what/when) in
//    EMPlusNodeHistory / GET /api/nodes/:id/history, instead of erasing it on every save.
//
// `useOriginDate`: when true, ignore `asOfDate` entirely and anchor this save to the node's
// own earliest recorded effectiveFrom (falling back to nodeItem.createdAt if it has no
// history yet) — i.e. the date the entity actually came into existence from a business
// standpoint. This matters because `createdAt` is just the literal system timestamp of the
// DB write; an entity imported via CSV with a backdated "effective as of" (e.g. 12/31/2025)
// has a *business* origin date earlier than that. Anchoring to the true origin, rather than
// a date a caller supplies, means `nextStartAfterIncoming` below can never find a legitimate
// "later" row to mistake for a pending future version IF — and only if — every other row for
// this node already shares that same origin date. Pre-existing nodes whose history still has
// genuinely varying dates (any node edited before this policy existed, since the old UI
// defaulted an edit's date to "today") need the one-time server/scripts/normalizeNodeEffectiveDates.js
// migration to flatten their history onto this same anchor; this flag alone does not retroactively
// fix already-divergent historical dates.
const persistNodeVersion = async ({ clientId, nodeItem, asOfDate, changedBy, mode = "upsert", replaceSameStart = true, useOriginDate = false }) => {
  if (!nodeItem?.nodeId) {
    throw Object.assign(new Error("nodeItem.nodeId is required"), { status: 400 });
  }
  const now = new Date().toISOString();
  const nodeId = nodeItem.nodeId;

  const nodeHistoryAll = (await queryNodeHistoryForNode(clientId, nodeId))
    .filter((row) => row.nodeId === nodeId);

  const effectiveFrom = useOriginDate
    ? (
        nodeHistoryAll
          .map((row) => normalizeDateInput(row.effectiveFrom))
          .filter(Boolean)
          .sort((a, b) => a.localeCompare(b))[0]
        || normalizeDateInput(nodeItem.createdAt)
        || now.slice(0, 10)
      )
    : (normalizeDateInput(asOfDate) || now.slice(0, 10));
  const versionId = `${effectiveFrom}-${randomBytes(8).toString("hex")}`;

  const sameStartRows = replaceSameStart
    ? nodeHistoryAll.filter((row) => normalizeDateInput(row.effectiveFrom) === effectiveFrom)
    : [];
  await Promise.all(
    sameStartRows.map((row) => deleteNodeHistory(clientId, row.nodeHistoryKey))
  );

  const nodeHistory = replaceSameStart
    ? nodeHistoryAll.filter((row) => normalizeDateInput(row.effectiveFrom) !== effectiveFrom)
    : nodeHistoryAll;

  const nextStartAfterIncoming = nodeHistory
    .map((row) => normalizeDateInput(row.effectiveFrom))
    .filter(Boolean)
    .filter((start) => start > effectiveFrom)
    .sort((a, b) => a.localeCompare(b))[0] || null;

  const activeAtIncoming = nodeHistory.filter((row) => isNodeActiveAt(row, effectiveFrom));
  await Promise.all(
    activeAtIncoming
      .filter((row) => (row.effectiveFrom || "0001-01-01") < effectiveFrom)
      .map((row) =>
        putNodeHistory({
          ...row,
          effectiveTo: effectiveFrom,
          closedAt: now,
          closedBy: changedBy || null,
        })
      )
  );

  const shouldReplaceCurrent = !nextStartAfterIncoming;
  if (shouldReplaceCurrent) {
    await Promise.all(
      nodeHistory
        .filter((row) => !row.effectiveTo)
        .map((row) =>
          putNodeHistory({
            ...row,
            effectiveTo: effectiveFrom,
            closedAt: now,
            closedBy: changedBy || null,
          })
        )
    );
  }

  if (mode === "delete") {
    if (shouldReplaceCurrent) {
      await deleteNode(clientId, nodeId);
      // Tombstone: Recorded/audit-date mode picks "most recently changed" rows by
      // changedAt alone (ignoring effective dating), so without this marker a deleted
      // node would appear to live on forever in that mode. Effective-dated mode already
      // explicitly excludes deleted rows (see isNodeActiveAt callers), so this is inert there.
      await putNodeHistory({
        clientId,
        nodeId,
        id: nodeId,
        nodeHistoryKey: makeNodeHistoryKey({ nodeId, effectiveFrom, versionId }),
        effectiveFrom,
        effectiveTo: nextStartAfterIncoming,
        versionId,
        changedAt: now,
        changedBy: changedBy || null,
        wasCurrent: true,
        deleted: true,
      });
    }
    return null;
  }

  const historyItem = {
    ...nodeItem,
    clientId,
    nodeHistoryKey: makeNodeHistoryKey({ nodeId, effectiveFrom, versionId }),
    effectiveFrom,
    effectiveTo: nextStartAfterIncoming,
    versionId,
    changedAt: now,
    changedBy: changedBy || null,
    // Recorded/audit-date mode only considers rows that were ever the live "current"
    // record — this distinguishes a normal edit from a backdated historical insert that
    // never actually appeared as the live view (shouldReplaceCurrent === false).
    wasCurrent: shouldReplaceCurrent,
  };
  await putNodeHistory(historyItem);

  if (shouldReplaceCurrent) {
    await putNode(nodeItem);
    return nodeItem;
  }
  return historyItem;
};

const buildOwnsItem = (
  { from, to, percent, startDate, endDate, client, createdAt, updatedAt }
) => ({
  clientId: client,
  relKey: makeRelKey("owns", from, to),
  id: `owns-${from}-${to}`,
  type: "owns",
  from,
  to,
  percent: percent ?? null,
  startDate: startDate || null,
  endDate: endDate || null,
  client,
  createdAt,
  updatedAt,
});

const makeOwnershipCurrentKey = (from, to) => `OWNS#${from}#${to}`;

const makeOwnershipHistoryKey = ({ to, effectiveFrom, from, setId }) =>
  `OWNED#${to}#FROM#${from}#AT#${effectiveFrom}#SET#${setId}`;

const isOwnershipActiveAt = (rel, asOf) => {
  const start = rel.effectiveFrom || "0001-01-01";
  const end = rel.effectiveTo || "9999-12-31";
  return start <= asOf && end > asOf;
};

const dedupeOwnershipRows = (rows) => {
  const map = new Map();
  (rows || []).forEach((row) => {
    if (!row?.from || !row?.to) return;
    map.set(`${row.from}=>${row.to}`, row);
  });
  return [...map.values()];
};

const validateOwnershipSet = (rows, ownedId = null) => {
  const EPS = 0.0001;
  const total = rows.reduce((sum, row) => sum + (Number(row.percent) || 0), 0);
  const totalRounded = Math.round(total * 10000) / 10000;
  const totalIsZero = Math.abs(totalRounded) <= EPS;
  const totalIsHundred = Math.abs(totalRounded - 100) <= EPS;
  if (!totalIsZero && !totalIsHundred) {
    const entityInfo = ownedId ? ` for entity "${ownedId}"` : "";
    throw Object.assign(
      new Error(`ownership total must be exactly 0 or 100 (got ${totalRounded})${entityInfo}`),
      { status: 400 }
    );
  }
};

const listOwnershipRows = async (clientId, asOf = null) => {
  const targetAsOf = asOf || null;
  if (targetAsOf) {
    try {
      const [historyRows, currentRows] = await Promise.all([
        queryOwnershipHistory(clientId),
        queryOwnershipCurrent(clientId),
      ]);
      const ownsRows = historyRows.filter((r) => r.type === "owns");

      // Compute effectiveTo for each row: the start of the next ownership set for the same owned entity.
      const startsByTo = {};
      ownsRows.forEach((r) => {
        if (!r.to || !r.effectiveFrom) return;
        if (!startsByTo[r.to]) startsByTo[r.to] = new Set();
        startsByTo[r.to].add(r.effectiveFrom);
      });
      const sortedStartsByTo = {};
      Object.keys(startsByTo).forEach((to) => {
        sortedStartsByTo[to] = [...startsByTo[to]].sort();
      });

      const withEffectiveTo = ownsRows.map((r) => {
        const starts = sortedStartsByTo[r.to] || [];
        const idx = starts.indexOf(r.effectiveFrom);
        const nextStart = (idx >= 0 && idx < starts.length - 1) ? starts[idx + 1] : null;
        return { ...r, effectiveTo: nextStart || r.effectiveTo || null };
      });

      const active = withEffectiveTo.filter((r) => isOwnershipActiveAt(r, targetAsOf));

      // Owned entities with zero ownership-history rows predate history tracking
      // (e.g. legacy/imported data that never went through persistOwnershipSet). With no
      // record of their ownership ever being different, assume it's always existed and
      // include their current ownership unconditionally.
      const historyToIds = new Set(ownsRows.map((r) => r.to));
      const currentOwns = currentRows.filter((r) => r.type === "owns");
      const untrackedCurrent = currentOwns.filter((r) => r.to && !historyToIds.has(r.to));

      // Return the filtered result regardless — even if empty.
      // An empty result correctly means "no ownership records active on this date".
      // Do NOT fall through to the legacy fallback, which has no date filtering.
      return dedupeOwnershipRows([...active, ...untrackedCurrent]);
    } catch (err) {
      console.warn("listOwnershipRows: history query failed, falling back to current:", err.message);
      // Only fall through on exception — not on legitimately empty results.
    }
  } else {
    try {
      const currentRows = await queryOwnershipCurrent(clientId);
      const currentOwns = currentRows.filter((r) => r.type === "owns");
      if (currentOwns.length > 0) return dedupeOwnershipRows(currentOwns);
    } catch (err) {
      console.warn("listOwnershipRows: current query failed, falling back to legacy:", err.message);
    }
  }

  // Backward-compat fallback during migration: keep serving legacy ownership rows
  // when the new ownership tables are empty (no asOf date path only).
  const legacy = await queryRels(clientId);
  return legacy
    .filter((r) => r.type === "owns")
    .filter((r) => (targetAsOf ? relActiveAt(r, targetAsOf) : true));
};

// Recorded/audit-date mode: for each owned entity, pick the ownership set (grouped by
// setId) whose changedAt is the most recent at-or-before the cutoff — among sets that
// were ever the live "current" ownership (wasCurrent !== false; legacy rows predating
// this field default to eligible). Ignores business effective dating entirely.
const listOwnershipRowsRecorded = async (clientId, cutoffIso) => {
  const [historyRows, currentRows] = await Promise.all([
    queryOwnershipHistory(clientId),
    queryOwnershipCurrent(clientId),
  ]);
  const ownsHistory = historyRows.filter((r) => r.type === "owns");
  const eligible = ownsHistory.filter(
    (r) => r.wasCurrent !== false && r.changedAt && r.changedAt <= cutoffIso
  );

  const bestSetIdByTo = new Map(); // to -> { setId, changedAt }
  eligible.forEach((r) => {
    if (!r.to || !r.setId) return;
    const existing = bestSetIdByTo.get(r.to);
    if (!existing || r.changedAt > existing.changedAt) {
      bestSetIdByTo.set(r.to, { setId: r.setId, changedAt: r.changedAt });
    }
  });

  const results = [];
  bestSetIdByTo.forEach(({ setId }, to) => {
    eligible
      .filter((r) => r.to === to && r.setId === setId)
      .forEach((r) => results.push(r));
  });

  // Owned entities with zero ownership-history rows at all predate history tracking —
  // assume their current ownership has always existed.
  const historyToIds = new Set(ownsHistory.map((r) => r.to));
  const currentOwns = currentRows.filter((r) => r.type === "owns");
  currentOwns
    .filter((r) => r.to && !historyToIds.has(r.to))
    .forEach((r) => results.push(r));

  return dedupeOwnershipRows(results);
};

const persistOwnershipSet = async ({ clientId, ownedId, rows, asOfDate, changedBy }) => {
  const setRows = (rows || []).map((row) => ({
    from: row.from,
    to: ownedId,
    percent: Number(row.percent),
  }));
  if (setRows.length === 0) {
    throw Object.assign(new Error("ownership set must contain at least one owner"), { status: 400 });
  }
  if (setRows.some((row) => !row.from || !Number.isFinite(row.percent))) {
    throw Object.assign(new Error("each ownership row requires from and numeric percent"), { status: 400 });
  }
  validateOwnershipSet(setRows, ownedId);

  const now = new Date().toISOString();
  const effectiveFrom = normalizeDateInput(asOfDate);
  if (!effectiveFrom) {
    throw Object.assign(new Error("asOfDate (YYYY-MM-DD) is required"), { status: 400 });
  }
  const setId = `${effectiveFrom}-${randomBytes(8).toString("hex")}`;

  const [allCurrent, allHistory] = await Promise.all([
    queryOwnershipCurrent(clientId),
    queryOwnershipHistory(clientId),
  ]);

  const currentForOwned = allCurrent.filter((r) => r.type === "owns" && r.to === ownedId);
  const historyForOwnedAll = allHistory.filter((r) => r.type === "owns" && r.to === ownedId);
  const sameStartRows = historyForOwnedAll.filter(
    (row) => normalizeDateInput(row.effectiveFrom) === effectiveFrom
  );

  // Same effectiveFrom means "replace that dated set", not append a duplicate set.
  await Promise.all(
    sameStartRows.map((row) => deleteOwnershipHistory(clientId, row.ownershipHistoryKey))
  );

  const historyForOwned = historyForOwnedAll.filter(
    (row) => normalizeDateInput(row.effectiveFrom) !== effectiveFrom
  );

  const nextStartAfterIncoming = historyForOwned
    .map((row) => normalizeDateInput(row.effectiveFrom))
    .filter(Boolean)
    .filter((start) => start > effectiveFrom)
    .sort((a, b) => a.localeCompare(b))[0] || null;

  // With computed effectiveTo, we don't need to "close" existing periods - their end dates
  // are automatically computed from the next period's start date when fetching.
  // Just delete any duplicate sets with the same effectiveFrom (replace logic).
  
  const shouldReplaceCurrent = !nextStartAfterIncoming;
  if (shouldReplaceCurrent) {
    // This new period is the latest, so it becomes the "current" period
    // Delete any old current records for this entity
    await Promise.all(
      currentForOwned.map((r) => deleteOwnershipCurrent(clientId, r.ownershipKey))
    );
  }

  const historyItems = setRows.map((row) => ({
    clientId,
    ownershipHistoryKey: makeOwnershipHistoryKey({
      to: ownedId,
      effectiveFrom,
      from: row.from,
      setId,
    }),
    id: `owns-${row.from}-${ownedId}`,
    type: "owns",
    from: row.from,
    to: ownedId,
    percent: row.percent,
    effectiveFrom,
    // Do NOT store effectiveTo - it will be computed from next period's effectiveFrom
    setId,
    changedAt: now,
    changedBy: changedBy || null,
    // Recorded/audit-date mode only considers sets that were ever the live "current"
    // ownership — this distinguishes a normal edit from a backdated historical insert
    // that never actually appeared as the live view (shouldReplaceCurrent === false).
    wasCurrent: shouldReplaceCurrent,
  }));

  const currentItems = setRows.map((row) => ({
    clientId,
    ownershipKey: makeOwnershipCurrentKey(row.from, ownedId),
    id: `owns-${row.from}-${ownedId}`,
    type: "owns",
    from: row.from,
    to: ownedId,
    percent: row.percent,
    effectiveFrom,
    // Do NOT store effectiveTo - it will be computed from next period's effectiveFrom
    setId,
    changedAt: now,
    changedBy: changedBy || null,
  }));

  await batchPutOwnershipHistory(historyItems);
  console.log(`[persistOwnershipSet] Wrote ${historyItems.length} history items for ${ownedId} as of ${effectiveFrom}`);
  
  if (shouldReplaceCurrent) {
    console.log(`[persistOwnershipSet] Writing ${currentItems.length} current items for ${ownedId} (latest period)`);
    await Promise.all(currentItems.map((item) => putOwnershipCurrent(item)));
    console.log(`[persistOwnershipSet] Successfully wrote ${currentItems.length} current items for ${ownedId}`);
    return currentItems;
  }

  return historyItems;
};

const buildEmploysItem = (
  { from, to, role, startDate, endDate, client, createdAt, updatedAt }
) => ({
  clientId: client,
  relKey: makeRelKey("employs", from, to),
  id: `employs-${from}-${to}`,
  type: "employs",
  from,
  to,
  role: role || null,
  startDate: startDate || null,
  endDate: endDate || null,
  client,
  createdAt,
  updatedAt,
});

// Strip DynamoDB-internal keys before sending to the frontend.
const toNodeResponse = ({
  clientId: _c,
  nodeId: _n,
  nodeHistoryKey: _h,
  effectiveFrom: _ef,
  effectiveTo: _et,
  versionId: _v,
  changedAt: _ca,
  changedBy: _cb,
  closedAt: _clA,
  closedBy: _clB,
  wasCurrent: _wc,
  deleted: _del,
  ...rest
}) => rest;
const toRelResponse = ({ clientId: _c, relKey: _r, wasCurrent: _wc, ...rest }) => rest;

// Check whether a relationship is active on a given date string (YYYY-MM-DD).
const relActiveAt = (rel, asOf) => {
  const start = rel.startDate || "0001-01-01";
  const end = rel.endDate || "9999-12-31";
  return start <= asOf && end >= asOf;
};

// Delete every relationship that references nodeId (both directions).
const deleteRelsForNode = async (clientId, nodeId) => {
  const [fromRels, toRels] = await Promise.all([
    queryRelsByFrom(nodeId),
    queryRelsByTo(nodeId),
  ]);
  await Promise.all(
    [...fromRels, ...toRels].map((r) => deleteRel(clientId, r.relKey))
  );
};

const deleteOwnershipReferencesForNode = async (clientId, nodeId) => {
  const [currentRows, historyRows] = await Promise.all([
    queryOwnershipCurrent(clientId),
    queryOwnershipHistory(clientId),
  ]);
  const nowIso = new Date().toISOString();
  const today = nowIso.slice(0, 10);
  const currentMatches = currentRows.filter((r) => r.from === nodeId || r.to === nodeId);
  const openHistoryMatches = historyRows.filter((r) => (r.from === nodeId || r.to === nodeId) && !r.effectiveTo);

  await Promise.all(currentMatches.map((r) => deleteOwnershipCurrent(clientId, r.ownershipKey)));
  await Promise.all(
    openHistoryMatches.map((row) =>
      putOwnershipHistory({
        ...row,
        effectiveTo: today,
        closedAt: nowIso,
        closedBy: "system",
      })
    )
  );
};

// ─── Express app ──────────────────────────────────────────────────────────────

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

// ─── S3 (optional — only active when S3_BUCKET_UPLOADS env var is set) ───────
const S3_BUCKET = process.env.S3_BUCKET_UPLOADS || null;
const s3 = S3_BUCKET
  ? new S3Client({ region: process.env.AWS_REGION || "us-east-1" })
  : null;

app.use(
  cors({
    origin: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);
app.options("*", cors());
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "dynamodb-api", version: "2026-05-06.operationalRole", features: ["client management"] });
});

// ─── AUTH ROUTES (no JWT required) ───────────────────────────────────────────

app.post("/api/auth/login", async (req, res) => {
  try {
    const { loginId, password } = req.body || {};
    if (!loginId || !password) {
      return res.status(400).json({ error: "loginId and password are required" });
    }
    const user = await getUser(String(loginId).toLowerCase().trim());
    if (!user) return res.status(401).json({ error: "Invalid credentials" });
    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) return res.status(401).json({ error: "Invalid credentials" });
    const token = jwt.sign(
      { loginId: user.loginId, clientId: user.clientId, personId: user.personId || null },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRY }
    );
    res.json({ token, clientId: user.clientId, personId: user.personId || null, role: user.role || "user" });
  } catch (err) {
    console.error("/api/auth/login error", err);
    res.status(500).json({ error: err.message });
  }
});

// Bootstrap: register the FIRST user for a brand-new client.
// Requires SETUP_SECRET when set (guards against unauthorized client creation).
// Rejects the request if the client already has users — use POST /api/auth/users instead.
app.post("/api/auth/register", async (req, res) => {
  try {
    const { loginId, password, clientId, personId, setupSecret } = req.body || {};
    if (!loginId || !password || !clientId) {
      return res.status(400).json({ error: "loginId, password, clientId are required" });
    }
    // Block if this client already has users — they should use the in-app Add User feature
    const existingCount = await countUsersByClient(clientId);
    if (existingCount > 0) {
      return res.status(403).json({ error: "Client already exists. Add users via the in-app Settings menu." });
    }
    // Require SETUP_SECRET for new-client provisioning
    if (SETUP_SECRET && setupSecret !== SETUP_SECRET) {
      return res.status(403).json({ error: "Setup secret required to provision a new client" });
    }
    const normalizedId = String(loginId).toLowerCase().trim();
    const existing = await getUser(normalizedId);
    if (existing) return res.status(409).json({ error: "loginId already exists" });
    const passwordHash = await bcrypt.hash(password, 10);
    const user = {
      loginId: normalizedId,
      clientId,
      personId: personId || null,
      role: "admin", // bootstrap user is always an admin
      passwordHash,
      createdAt: new Date().toISOString(),
    };
    await putUser(user);
    res.status(201).json({ loginId: user.loginId, clientId: user.clientId, role: user.role });
  } catch (err) {
    console.error("/api/auth/register error", err);
    res.status(500).json({ error: err.message });
  }
});

// POST /api/auth/promote — break-glass: elevate a user to admin using SETUP_SECRET.
// Declared before JWT middleware intentionally — no token required.
app.post("/api/auth/promote", async (req, res) => {
  try {
    if (!SETUP_SECRET) {
      return res.status(403).json({ error: "SETUP_SECRET is not configured on this server" });
    }
    const { loginId, setupSecret } = req.body || {};
    if (!loginId || !setupSecret) {
      return res.status(400).json({ error: "loginId and setupSecret are required" });
    }
    if (setupSecret !== SETUP_SECRET) {
      return res.status(403).json({ error: "Invalid setup secret" });
    }
    const user = await getUser(String(loginId).toLowerCase().trim());
    if (!user) return res.status(404).json({ error: "User not found" });
    await putUser({ ...user, role: "admin" });
    res.json({ loginId: user.loginId, role: "admin" });
  } catch (err) {
    console.error("/api/auth/promote error", err);
    res.status(500).json({ error: err.message });
  }
});

// ─── JWT MIDDLEWARE (all /api/* routes below this require a valid token) ──────

app.use("/api", (req, res, next) => {
  // Skip only the unauthenticated auth endpoints
  if (req.path === "/auth/login" || req.path === "/auth/register") return next();
  if (req.path === "/health") return next();
  const authHeader = req.headers["authorization"] || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Unauthorized" });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.auth = payload; // { loginId, clientId, personId }
    next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
});

// ─── Admin middleware ────────────────────────────────────────────────────────
// Use as a route-level middleware: app.get("/api/foo", requireAdmin, handler)
const requireAdmin = async (req, res, next) => {
  try {
    const user = await getUser(req.auth.loginId);
    if (!user || user.role !== "admin") {
      return res.status(403).json({ error: "Admin access required" });
    }
    next();
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /api/admin/impersonate — issue a user-scoped token for an admin to test
// another account in the same client. The token retains the initiating admin ID.
app.post("/api/admin/impersonate", requireAdmin, async (req, res) => {
  try {
    if (req.auth.emulatedBy) {
      return res.status(403).json({ error: "An emulated session cannot start another emulation" });
    }
    const { loginId } = req.body || {};
    if (!loginId || typeof loginId !== "string") {
      return res.status(400).json({ error: "loginId is required" });
    }
    const targetLoginId = loginId.toLowerCase().trim();
    if (!targetLoginId) {
      return res.status(400).json({ error: "loginId is required" });
    }
    const user = await getUser(targetLoginId);
    if (!user) return res.status(404).json({ error: "User not found" });
    if (user.clientId !== req.auth.clientId) {
      return res.status(403).json({ error: "User belongs to a different client" });
    }
    if (targetLoginId === req.auth.loginId) {
      return res.status(400).json({ error: "You are already signed in as this user" });
    }

    const token = jwt.sign(
      {
        loginId: user.loginId,
        clientId: user.clientId,
        personId: user.personId || null,
        emulatedBy: req.auth.loginId,
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRY }
    );
    res.json({
      token,
      loginId: user.loginId,
      clientId: user.clientId,
      personId: user.personId || null,
      emulatedBy: req.auth.loginId,
    });
  } catch (err) {
    console.error("/api/admin/impersonate error", err);
    res.status(500).json({ error: err.message });
  }
});

// openCypher has been removed — backend now uses DynamoDB.
app.post("/api/cypher", (_req, res) => {
  res.status(410).json({ error: "openCypher endpoint removed; backend now uses DynamoDB." });
});

app.post("/api/graph", async (req, res) => {
  try {
    const clientId = req.auth.clientId;
    const { focusId, asOf } = req.body || {};
    if (!focusId || !asOf) {
      return res.status(400).json({ error: "focusId and asOf are required" });
    }
    const focusKey = normalizeClientId(clientId, focusId);

    // Fetch focus node and current employs relationships in parallel.
    const [nodeRows, fromRels, toRels, ownershipRows] = await Promise.all([
      listNodeRows(clientId, asOf),
      queryRelsByFrom(focusKey),
      queryRelsByTo(focusKey),
      listOwnershipRows(clientId, asOf),
    ]);

    const nodeById = new Map(nodeRows.map((item) => [item.id, item]));
    const focusItem = nodeById.get(focusKey) || null;

    if (!focusItem) {
      return res.status(404).json({ error: "node not found" });
    }

    const activeFrom = fromRels
      .filter((r) => r.type === "employs")
      .filter((r) => relActiveAt(r, asOf));
    const activeTo = toRels
      .filter((r) => r.type === "employs")
      .filter((r) => relActiveAt(r, asOf));
    const ownershipToFocus = ownershipRows.filter((r) => r.to === focusKey);
    const ownershipFromFocus = ownershipRows.filter((r) => r.from === focusKey);

    // Fetch all neighbor nodes in parallel.
    const neighborIds = new Set([
      ...ownershipToFocus.map((r) => r.from),
      ...ownershipFromFocus.map((r) => r.to),
      ...activeFrom.map((r) => r.to),
      ...activeTo.map((r) => r.from),
    ]);
    const neighborMap = new Map(
      [...neighborIds]
        .map((nid) => nodeById.get(nid))
        .filter(Boolean)
        .map((item) => [item.id, toNodeResponse(item)])
    );

    res.json({
      node: toNodeResponse(focusItem),
      owners: ownershipToFocus
        .map((r) => ({ node: neighborMap.get(r.from) || null, rel: toRelResponse(r), direction: "in" }))
        .filter((x) => x.node),
      owns: ownershipFromFocus
        .map((r) => ({ node: neighborMap.get(r.to) || null, rel: toRelResponse(r), direction: "out" }))
        .filter((x) => x.node),
      employees: activeFrom
        .map((r) => ({ node: neighborMap.get(r.to) || null, rel: toRelResponse(r), direction: "out" }))
        .filter((x) => x.node),
      employers: activeTo
        .map((r) => ({ node: neighborMap.get(r.from) || null, rel: toRelResponse(r), direction: "in" }))
        .filter((x) => x.node),
    });
  } catch (err) {
    console.error("/api/graph error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.post("/api/directory", async (req, res) => {
  try {
    const client = req.auth.clientId;
    // By default the directory always reflects current data. An optional `asOf`
    // (YYYY-MM-DD) opts into the "Time Machine": a read-only reconstruction of the
    // whole directory as it looked on that date. This never happens unless a caller
    // explicitly asks for it — see /api/nodes/:id/history and
    // /api/ownership/history/:entityId for the equivalent per-entity audit trail.
    //
    // Two reconstruction modes:
    //  - "effective" (default): business effective-from/to dating.
    //  - "recorded": what a live query would literally have shown at that real-world
    //    instant, ignoring effective dating — selected by each record's changedAt.
    const asOf = normalizeDateInput(req.body?.asOf) || null;
    const mode = req.body?.mode === "recorded" ? "recorded" : "effective";
    let nodeItems;
    let ownershipRows;
    if (asOf && mode === "recorded") {
      const cutoffIso = `${asOf}T23:59:59.999Z`;
      [nodeItems, ownershipRows] = await Promise.all([
        listNodeRowsRecorded(client, cutoffIso),
        listOwnershipRowsRecorded(client, cutoffIso),
      ]);
    } else {
      [nodeItems, ownershipRows] = await Promise.all([
        listNodeRows(client, asOf),
        listOwnershipRows(client, asOf),
      ]);
    }
    const relItems = await queryRels(client);
    // Employment relationships aren't tracked in the audit-date (changedAt) system —
    // they only carry business effective dates, so both modes use the same filter here.
    const employs = relItems
      .filter((r) => r.type === "employs")
      .filter((r) => (asOf ? relActiveAt(r, asOf) : true));
    res.json({
      nodes: nodeItems.map(toNodeResponse),
      rels: [...ownershipRows, ...employs].map(toRelResponse),
      asOf,
      mode: asOf ? mode : null,
    });
  } catch (err) {
    console.error("/api/directory error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.post("/api/nodes", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const {
      id, name, kind, address, workPhone, cellPhone, emails,
      photo, taxId, accountingUrl, hrUrl, logo, customFields,
      operationalRole, legalStatus, personStatus, notes,
    } = req.body || {};
    if (!name || !kind) {
      return res.status(400).json({ error: "name and kind are required" });
    }
    // IDs are permanent and never reused: if the requested/derived ID belongs to an existing
    // node or to any history (including deleted nodes), allocate a suffixed one instead.
    const baseId = normalizeClientId(client, id || `${kind}:${slugify(name) || "node"}`);
    let normalizedId = baseId;
    for (
      let n = 2;
      (await nodeHasHistory(client, normalizedId)) || (await getNode(client, normalizedId));
      n += 1
    ) {
      normalizedId = `${baseId}-${n}`;
    }
    const now = new Date().toISOString();
    const item = buildNodeItem({
      id: normalizedId, name, kind, client, address, workPhone, cellPhone,
      emails, photo, taxId, accountingUrl, hrUrl, logo, customFields,
      operationalRole, legalStatus, personStatus, notes,
      createdAt: now,
      updatedAt: now,
    });
    // A new entity is, by definition, effective from the moment it's created — not a
    // client-supplied date — so asOfDate is computed here rather than trusted from the
    // request.
    await persistNodeVersion({
      clientId: client,
      nodeItem: item,
      asOfDate: now.slice(0, 10),
      changedBy: req.auth.loginId,
      mode: "upsert",
    });
    res.json(toNodeResponse(item));
  } catch (err) {
    console.error("/api/nodes error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// ─── Helper shared by both nodes-csv endpoints ────────────────────────────────

const importNodeRows = async (rows, client, asOfDate) => {
  const now = new Date().toISOString();
  const importBatchId = now;
  // Imported entities are new records, effective from the moment they're created. An
  // explicit asOfDate is still honored if a caller supplies one (e.g. a historical
  // backfill), but it's no longer required — entities no longer have a UI for picking it.
  const effectiveAsOf = normalizeDateInput(asOfDate) || now.slice(0, 10);
  const items = rows.map((row) =>
    buildNodeItem({
      id: row.id, name: row.name, kind: row.kind, client,
      createdAt: now, updatedAt: now,
    })
  );
  for (const item of items) {
    // eslint-disable-next-line no-await-in-loop
    await persistNodeVersion({
      clientId: client,
      nodeItem: { ...item, importBatchId },
      asOfDate: effectiveAsOf,
      changedBy: "import",
      mode: "upsert",
    });
  }
  return { importBatchId, entities: rows.filter((r) => r.kind === "entity").length, persons: rows.filter((r) => r.kind === "person").length };
};

app.post("/api/import/nodes-csv", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { csv, defaultKind, asOfDate } = req.body || {};
    if (!csv) {
      return res.status(400).json({ error: "csv is required" });
    }
    const { rows, skipped } = parseNodeCsv(csv, defaultKind || "entity", client);
    if (!rows.length) {
      return res.status(400).json({ error: "no valid rows found in csv" });
    }
    const { importBatchId, entities, persons } = await importNodeRows(rows, client, asOfDate);
    res.json({ ok: true, total: rows.length, entities, persons, skipped, importBatchId });
  } catch (err) {
    console.error("/api/import/nodes-csv error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.post("/api/import/nodes-csv/upload", upload.single("file"), async (req, res) => {
  try {
    const client = req.auth.clientId;
    const defaultKind = req.body?.defaultKind || "entity";
    const asOfDate = req.body?.asOfDate || null;
    if (!req.file?.buffer) return res.status(400).json({ error: "file is required" });

    const ext = (req.file.originalname || "").split(".").pop().toLowerCase();
    const isXlsx = ext === "xlsx" || ext === "xls";
    const csv = isXlsx ? xlsxBufferToCsv(req.file.buffer) : req.file.buffer.toString("utf-8");
    const { rows, skipped } = parseNodeCsv(csv, defaultKind, client);
    if (!rows.length) {
      return res.status(400).json({ error: "no valid rows found in csv" });
    }
    const { importBatchId, entities, persons } = await importNodeRows(rows, client, asOfDate);
    res.json({ ok: true, total: rows.length, entities, persons, skipped, importBatchId });
  } catch (err) {
    console.error("/api/import/nodes-csv/upload error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// ─── Helper shared by both ownerships-csv endpoints ───────────────────────────

const resolveOwnershipRows = async (rows, client) => {
  // Load all nodes for this client once and build a name→id map in memory.
  const allNodes = await queryNodes(client);
  const nameMap = new Map();
  const validNodeIds = new Set();
  allNodes.forEach((item) => {
    if (item.name) nameMap.set(item.name.toLowerCase(), item.id);
    if (item.id) validNodeIds.add(item.id);
  });

  const resolved = [];
  const errors = [];
  rows.forEach((row, idx) => {
    const ownerRaw = String(row.owner || "").trim();
    const ownedRaw = String(row.owned || "").trim();
    const percent = Number(row.percent);

    const ownerId = ownerRaw.includes(":")
      ? normalizeClientId(client, ownerRaw)
      : nameMap.get(ownerRaw.toLowerCase());
    const ownedId = ownedRaw.includes(":")
      ? normalizeClientId(client, ownedRaw)
      : nameMap.get(ownedRaw.toLowerCase());

    if (!ownerId || !validNodeIds.has(ownerId)) { errors.push({ row: idx + 1, reason: "owner not found", owner: ownerRaw }); return; }
    if (!ownedId || !validNodeIds.has(ownedId)) { errors.push({ row: idx + 1, reason: "owned entity not found", owned: ownedRaw }); return; }
    if (!Number.isFinite(percent)) { errors.push({ row: idx + 1, reason: "percent missing or invalid", percent: row.percent }); return; }

    resolved.push({ from: ownerId, to: ownedId, percent });
  });
  return { resolved, errors };
};
// Evaluates the total ownership percentages for each owned entity, ensuring that the sum of
// ownership percentages is either exactly 0 or 100, and tracks rows with invalid percent values.

const evaluateOwnershipTotals = (rows) => {
  const groups = new Map();
  rows.forEach((row, idx) => {
    const owned = String(row.owned || "").trim();
    if (!owned) return;
    if (!groups.has(owned)) {
      groups.set(owned, {
        owned,
        total: 0,
        rowCount: 0,
        invalidPercentRows: [],
      });
    }
    const group = groups.get(owned);
    group.rowCount += 1;
    const pct = Number(row.percent);
    if (Number.isFinite(pct)) {
      group.total += pct;
    } else {
      group.invalidPercentRows.push(idx + 1);
    }
  });

  const EPS = 0.0001;
  const offendingEntities = [];
  for (const group of groups.values()) {
    const totalRounded = Math.round(group.total * 10000) / 10000;
    const totalIsZero = Math.abs(totalRounded - 0) <= EPS;
    const totalIsHundred = Math.abs(totalRounded - 100) <= EPS;
    const hasInvalidPercent = group.invalidPercentRows.length > 0;
    if (hasInvalidPercent || (!totalIsZero && !totalIsHundred)) {
      offendingEntities.push({
        owned: group.owned,
        total: totalRounded,
        rowCount: group.rowCount,
        invalidPercentRows: group.invalidPercentRows,
        reason: hasInvalidPercent
          ? "one or more rows have an invalid percent"
          : "total ownership must be exactly 0 or 100",
      });
    }
  }

  offendingEntities.sort((a, b) =>
    String(a.owned).localeCompare(String(b.owned), undefined, { sensitivity: "base" })
  );

  return {
    valid: offendingEntities.length === 0,
    offendingCount: offendingEntities.length,
    offendingEntities,
  };
};

const importOwnershipRows = async (resolved, client, asOfDate) => {
  const importBatchId = new Date().toISOString();
  const effectiveAsOf = normalizeDateInput(asOfDate);
  if (!effectiveAsOf) {
    throw Object.assign(new Error("asOfDate (YYYY-MM-DD) is required for ownership imports"), { status: 400 });
  }
  const groups = new Map();
  resolved.forEach((row) => {
    const key = row.to;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(row);
  });

  console.log(`[importOwnershipRows] Processing ${groups.size} entity groups from ${resolved.length} resolved rows`);
  const skippedGroups = [];
  const EPS = 0.0001;

  for (const [ownedId, rows] of groups.entries()) {
    // Re-validate totals after resolution — some rows may have been dropped due to
    // unresolvable owner names, leaving the group with an incomplete percentage total.
    const total = Math.round(rows.reduce((sum, r) => sum + (Number(r.percent) || 0), 0) * 10000) / 10000;
    const totalIsZero = Math.abs(total) <= EPS;
    const totalIsHundred = Math.abs(total - 100) <= EPS;
    if (!totalIsZero && !totalIsHundred) {
      skippedGroups.push({ ownedId, total, rowCount: rows.length, reason: `ownership rows sum to ${total}% after resolving names — likely some owner names were not found` });
      console.log(`[importOwnershipRows] Skipped ${ownedId}: ${rows.length} rows sum to ${total}%`);
      continue;
    }
    // eslint-disable-next-line no-await-in-loop
    await persistOwnershipSet({
      clientId: client,
      ownedId,
      rows,
      asOfDate: effectiveAsOf,
      changedBy: "import",
    });
    console.log(`[importOwnershipRows] Successfully persisted ${rows.length} rows for ${ownedId}`);
  }
  console.log(`[importOwnershipRows] Complete: ${groups.size - skippedGroups.length} groups persisted, ${skippedGroups.length} skipped`);
  return { importBatchId, skippedGroups };
};

app.post("/api/import/ownerships-csv", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { csv, asOfDate } = req.body || {};
    if (!csv) {
      return res.status(400).json({ error: "csv is required" });
    }
    const { rows, skipped } = parseOwnershipCsv(csv);
    if (!rows.length) {
      return res.status(400).json({ error: "no valid rows found in csv" });
    }
    console.log(`[/api/import/ownerships-csv] CSV parsed: ${rows.length} rows, ${skipped} parse errors`);
    const { resolved, errors } = await resolveOwnershipRows(rows, client);
    console.log(`[/api/import/ownerships-csv] Name resolution: ${resolved.length} valid, ${errors.length} errors`);
    if (!resolved.length) {
      return res.status(400).json({ error: "no valid ownership rows to import", skipped: skipped + errors.length, errors });
    }
    const { importBatchId, skippedGroups } = await importOwnershipRows(resolved, client, asOfDate);
    console.log(`[/api/import/ownerships-csv] Import complete: ${resolved.length} resolved rows, ${skippedGroups.length} skipped groups`);
    
    const responseData = { ok: true, total: rows.length, imported: resolved.length, skipped: skipped + errors.length, errors, skippedGroups, importBatchId };
    const responseJson = JSON.stringify(responseData);
    console.log(`[/api/import/ownerships-csv] Sending response: ${responseJson.length} bytes`);
    
    res.json(responseData);
    console.log(`[/api/import/ownerships-csv] Response sent successfully`);
  } catch (err) {
    console.error("/api/import/ownerships-csv error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.post("/api/import/ownerships-csv/upload", upload.single("file"), async (req, res) => {
  try {
    const client = req.auth.clientId;
    const asOfDate = req.body?.asOfDate || null;
    if (!req.file?.buffer) return res.status(400).json({ error: "file is required" });

    const ext = (req.file.originalname || "").split(".").pop().toLowerCase();
    const isXlsx = ext === "xlsx" || ext === "xls";
    const csv = isXlsx ? xlsxBufferToCsv(req.file.buffer) : req.file.buffer.toString("utf-8");
    const { rows, skipped } = parseOwnershipCsv(csv);
    if (!rows.length) {
      return res.status(400).json({ error: "no valid rows found in csv" });
    }
    const { resolved, errors } = await resolveOwnershipRows(rows, client);
    if (!resolved.length) {
      return res.status(400).json({ error: "no valid ownership rows to import", skipped: skipped + errors.length, errors });
    }
    const { importBatchId, skippedGroups } = await importOwnershipRows(resolved, client, asOfDate);
    res.json({ ok: true, total: rows.length, imported: resolved.length, skipped: skipped + errors.length, errors, skippedGroups, importBatchId });
  } catch (err) {
    console.error("/api/import/ownerships-csv/upload error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// ─── Import preview (parse-only, no writes) ───────────────────────────────────

app.post("/api/import/preview/upload", upload.single("file"), async (req, res) => {
  try {
    const client = req.auth.clientId;
    const importType = req.body?.importType || "entity";
    const defaultKind = req.body?.defaultKind || "entity";
    if (!req.file?.buffer) return res.status(400).json({ error: "file is required" });

    const ext = (req.file.originalname || "").split(".").pop().toLowerCase();
    const isXlsx = ext === "xlsx" || ext === "xls";
    const MAX_PREVIEW = 50;

    if (importType === "details") {
      let rawRecords;
      if (isXlsx) {
        const workbook = XLSX.read(req.file.buffer, { type: "buffer" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        rawRecords = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });
      } else {
        rawRecords = parse(req.file.buffer.toString("utf-8"), { skip_empty_lines: true, relax_column_count: true, trim: true });
      }
      if (!rawRecords || rawRecords.length < 2) {
        return res.json({ headers: [], rows: [], total: 0, skipped: 0, truncated: false });
      }
      const { rows, skipped, mapping } = parseRecordsToDetailRows(rawRecords);
      const headers = rawRecords[0].map((h) => String(h ?? "")).filter((h) => h.trim());
      const previewRows = rawRecords.slice(1, MAX_PREVIEW + 1).map((record) =>
        headers.reduce((obj, h, i) => { obj[h] = String(record[i] ?? ""); return obj; }, {})
      );
      return res.json({ headers, rows: previewRows, total: rows.length, skipped, mapping, truncated: rows.length > MAX_PREVIEW });
    }

    if (importType === "ownership") {
      const csv = isXlsx ? xlsxBufferToCsv(req.file.buffer) : req.file.buffer.toString("utf-8");
      const { rows, skipped } = parseOwnershipCsv(csv);
      const ownershipValidation = evaluateOwnershipTotals(rows);
      const headers = ["Owner", "Owned", "Percent"];
      const previewRows = rows.slice(0, MAX_PREVIEW).map((r) => ({
        Owner: r.owner,
        Owned: r.owned,
        Percent: Number.isNaN(r.percent) ? "" : String(r.percent),
      }));
      return res.json({
        headers,
        rows: previewRows,
        total: rows.length,
        skipped,
        truncated: rows.length > MAX_PREVIEW,
        ownershipValidation,
      });
    }

    // entity or person
    const csv = isXlsx ? xlsxBufferToCsv(req.file.buffer) : req.file.buffer.toString("utf-8");
    const { rows, skipped } = parseNodeCsv(csv, defaultKind, client);
    const headers = ["Name", "Kind"];
    const previewRows = rows.slice(0, MAX_PREVIEW).map((r) => ({ Name: r.name, Kind: r.kind }));
    return res.json({ headers, rows: previewRows, total: rows.length, skipped, truncated: rows.length > MAX_PREVIEW });
  } catch (err) {
    console.error("/api/import/preview/upload error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// ─── Helper shared by both details endpoints ──────────────────────────────────

// Patches existing nodes with fields extracted from a details file.
// Looks up each row by name (case-insensitive). Unknown columns that landed in
// customFields are merged (not replaced) with whatever the node already has.
// Resolves or auto-creates a DD field for each unrecognised column header.
// Returns a map of rawHeader → fieldId so values can be stored under the correct key.
const resolveExtraHeaders = async (extraHeaders, client, existingFields = null) => {
  if (!extraHeaders || extraHeaders.length === 0) return {};

  const ddFields = existingFields || await queryDDFields(client);
  // Build lookup: normalised prompt → fieldId
  const existingByPrompt = new Map(
    ddFields.map((f) => [normalizeHeader(f.prompt || ""), f.fieldId])
  );

  const headerToFieldId = {};
  const now = new Date().toISOString();
  const toCreate = [];

  for (const rawHeader of extraHeaders) {
    if (!rawHeader.trim()) continue;
    const normalized = normalizeHeader(rawHeader);
    if (existingByPrompt.has(normalized)) {
      headerToFieldId[rawHeader] = existingByPrompt.get(normalized);
    } else {
      const fieldId = `dd:${slugify(rawHeader.trim())}-${Date.now().toString(36)}-${toCreate.length}`;
      const item = {
        clientId: client,
        fieldId,
        id: fieldId,
        prompt: rawHeader.trim(),
        dataType: "string",
        appliesTo: "both",
        multiValue: false,
        validValues: [],
        phoneTypes: [],
        showInStats: false,
        sortOrder: ddFields.length + toCreate.length,
        createdAt: now,
        updatedAt: now,
      };
      toCreate.push(item);
      headerToFieldId[rawHeader] = fieldId;
      existingByPrompt.set(normalized, fieldId); // prevent duplicates within the same batch
    }
  }

  if (toCreate.length) await Promise.all(toCreate.map((f) => putDDField(f)));
  return headerToFieldId;
};

// `asOfDate` is accepted for backward compatibility but intentionally unused: details
// imports update existing entities, so each row's effective date is always that entity's
// own creation date (computed per-row below), never a caller-supplied batch date.
const applyDetailRows = async (rows, extraHeaders, client, guessed = {}, preloadedDdFields = null, asOfDate = null, changedBy = null) => {
  const [allNodes, ddFields] = await Promise.all([
    queryNodes(client),
    preloadedDdFields != null ? Promise.resolve(preloadedDdFields) : queryDDFields(client),
  ]);

  // If a fuzzy-matched built-in header is an EXACT match for a DD field prompt,
  // the DD field takes precedence — re-route that column back to extraValues.
  const ddNormToPrompt = new Map(ddFields.map((f) => [normalizeHeader(f.prompt || ""), f.prompt]));
  const redirect = {}; // builtInFieldName → rawHeader
  for (const [rawHeader, builtInField] of Object.entries(guessed)) {
    if (ddNormToPrompt.has(normalizeHeader(rawHeader))) {
      redirect[builtInField] = rawHeader;
    }
  }

  const hasRedirects = Object.keys(redirect).length > 0;
  const adjustedRows = hasRedirects
    ? rows.map(({ name, patch, extraValues = {} }) => {
        const newPatch = { ...patch };
        const newExtraValues = { ...extraValues };
        for (const [field, rawHeader] of Object.entries(redirect)) {
          if (field in newPatch) {
            newExtraValues[rawHeader] = newPatch[field];
            delete newPatch[field];
          }
        }
        return { name, patch: newPatch, extraValues: newExtraValues };
      })
    : rows;

  const adjustedExtraHeaders = hasRedirects
    ? [...extraHeaders, ...Object.values(redirect)]
    : extraHeaders;

  const [headerToFieldId] = await Promise.all([
    resolveExtraHeaders(adjustedExtraHeaders, client, ddFields),
  ]);
  const nameMap = new Map(allNodes.map((n) => [String(n.name || "").toLowerCase(), n]));

  const now = new Date().toISOString();
  // Entities no longer support a per-edit effective date: each row is recorded as
  // effective from that specific entity's own origin date (`useOriginDate` in
  // persistNodeVersion, computed per-row from its existing history), not a single
  // shared date for the whole import batch.
  const importBatchId = now;
  const updated = [];
  const notFoundList = [];

  for (const { name, patch, extraValues = {} } of adjustedRows) {
    // Match by display name or by raw/prefixed id value
    const existing =
      nameMap.get(name.toLowerCase()) ||
      allNodes.find((n) => n.id === normalizeClientId(client, name));
    if (!existing) { notFoundList.push(name); continue; }

    // Remap extra column values from raw header name → DD fieldId.
    // Normalize date values according to the field's dataType.
    const fieldTypeMap = new Map(ddFields.map((f) => [f.fieldId, f.dataType]));
    const remappedExtra = {};
    for (const [rawHeader, value] of Object.entries(extraValues)) {
      const fieldId = headerToFieldId[rawHeader];
      if (!fieldId) continue;
      const dataType = fieldTypeMap.get(fieldId);
      remappedExtra[fieldId] = dataType === "date" ? (normalizeDateInput(value) || value) : value;
    }

    // Merge customFields: preserve existing keys; add/overwrite only keys present in this import.
    // Fields absent from the spreadsheet are NOT touched.
    const mergedCustomFields = {
      ...(existing.customFields || {}),
      ...remappedExtra,
    };

    // Never allow the details import to change a node's kind.
    delete patch.kind;

    const item = buildNodeItem({
      ...existing,
      ...patch,                  // only overwrites DD fields that were present & non-blank
      customFields: mergedCustomFields,
      emails: patch.emails !== undefined
        ? normalizeEmails(patch.emails)
        : existing.emails,
      client,
      createdAt: existing.createdAt || now,
      updatedAt: now,
    });
    updated.push({ ...item, importBatchId });
  }

  for (const item of updated) {
    // eslint-disable-next-line no-await-in-loop
    await persistNodeVersion({
      clientId: client,
      nodeItem: item,
      changedBy: changedBy || "import",
      mode: "upsert",
      replaceSameStart: false,
      useOriginDate: true,
    });
  }
  const ddCreated = Object.entries(headerToFieldId);
  return {
    updated: updated.length,
    notFound: notFoundList.length,
    notFoundList,
    ddFieldsCreated: ddCreated.map(([header, fieldId]) => ({ header, fieldId })),
  };
};

app.post("/api/import/details-csv", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { csv, asOfDate } = req.body || {};
    if (!csv) return res.status(400).json({ error: "csv is required" });

    const ddFields = await queryDDFields(client);
    const ddPromptsSet = new Set(ddFields.map((f) => normalizeHeader(f.prompt || "")));

    const { rows, extraHeaders, mapping, skipped } = parseDetailsCsv(csv, ddPromptsSet);
    if (!rows.length) return res.status(400).json({ error: "no valid rows found", mapping, skipped });

    const result = await applyDetailRows(rows, extraHeaders, client, mapping.guessed || {}, ddFields, asOfDate, req.auth.loginId);
    res.json({ ok: true, ...result, skipped, mapping });
  } catch (err) {
    console.error("/api/import/details-csv error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.post("/api/import/details-csv/upload", upload.single("file"), async (req, res) => {
  try {
    const client = req.auth.clientId;
    const asOfDate = req.body?.asOfDate || null;
    if (!req.file?.buffer) return res.status(400).json({ error: "file is required" });

    const ddFields = await queryDDFields(client);
    const ddPromptsSet = new Set(ddFields.map((f) => normalizeHeader(f.prompt || "")));

    const ext = (req.file.originalname || "").split(".").pop().toLowerCase();
    const isXlsx = ext === "xlsx" || ext === "xls";
    const { rows, extraHeaders, mapping, skipped } = isXlsx
      ? parseDetailsXlsx(req.file.buffer, ddPromptsSet)
      : parseDetailsCsv(req.file.buffer.toString("utf-8"), ddPromptsSet);

    if (!rows.length) return res.status(400).json({ error: "no valid rows found", mapping, skipped });

    const result = await applyDetailRows(rows, extraHeaders, client, mapping.guessed || {}, ddFields, asOfDate, req.auth.loginId);
    res.json({ ok: true, ...result, skipped, mapping });
  } catch (err) {
    console.error("/api/import/details-csv/upload error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.put("/api/nodes/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const client = req.auth.clientId;
    const {
      name, kind, address, workPhone, cellPhone, emails,
      photo, taxId, accountingUrl, hrUrl, logo, customFields,
      operationalRole, legalStatus, personStatus, notes,
    } = req.body || {};
    if (!id || !name || !kind) {
      return res.status(400).json({ error: "id, name, kind are required" });
    }
    // A node's ID is permanent; renaming only changes `name`. Any legacy `newId` is ignored.
    const normalizedId = normalizeClientId(client, id);
    const now = new Date().toISOString();

    const existing = await getNode(client, normalizedId);
    if (!existing) return res.status(404).json({ error: "node not found" });

    const item = buildNodeItem({
      id: normalizedId, name, kind, client, address, workPhone, cellPhone,
      emails, photo, taxId, accountingUrl, hrUrl, logo, customFields,
      operationalRole, legalStatus, personStatus,
      // Notes aren't shown in every editing surface, so a request that omits them (e.g. a
      // client built before Notes existed) keeps the stored value instead of wiping it.
      notes: notes !== undefined ? notes : existing.notes,
      createdAt: existing.createdAt || now,
      updatedAt: now,
    });
    // Entities no longer support a per-edit effective date — every field change is
    // recorded as effective from the entity's own origin date (its earliest recorded
    // effective date, which may predate `createdAt` for backdated imports — see
    // `useOriginDate` above), computed here rather than trusted from the request.
    // `replaceSameStart: false` keeps every prior edit's history row intact (instead of
    // overwriting it) so the full audit trail survives repeated edits that all share
    // this same effective date.
    await persistNodeVersion({
      clientId: client,
      nodeItem: item,
      changedBy: req.auth.loginId,
      mode: "upsert",
      replaceSameStart: false,
      useOriginDate: true,
    });

    res.json(toNodeResponse(item));
  } catch (err) {
    console.error("/api/nodes/:id error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.delete("/api/nodes/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const client = req.auth.clientId;
    const asOfDate = req.body?.asOfDate || null;
    if (!id) {
      return res.status(400).json({ error: "id is required" });
    }
    const normalizedId = normalizeClientId(client, id);
    // Detach-delete: remove all relationships first, then the node.
    await deleteRelsForNode(client, normalizedId);
    await deleteOwnershipReferencesForNode(client, normalizedId);
    await persistNodeVersion({
      clientId: client,
      nodeItem: { id: normalizedId, nodeId: normalizedId, clientId: client },
      asOfDate,
      changedBy: req.auth.loginId,
      mode: "delete",
    });
    res.json({ id: normalizedId });
  } catch (err) {
    console.error("/api/nodes/:id (delete) error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// ─── OWNS ─────────────────────────────────────────────────────────────────────

app.post("/api/relationships/owns", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { from, to, percent, asOfDate } = req.body || {};
    if (!from || !to) {
      return res.status(400).json({ error: "from and to are required" });
    }
    const fromId = normalizeClientId(client, from);
    const toId = normalizeClientId(client, to);
    const allCurrent = await queryOwnershipCurrent(client);
    const currentForOwned = allCurrent.filter((r) => r.type === "owns" && r.to === toId);
    const existingIdx = currentForOwned.findIndex((r) => r.from === fromId);
    const nextRows = currentForOwned.map((r) => ({ from: r.from, to: toId, percent: r.percent }));
    const nextRow = { from: fromId, to: toId, percent: percent ?? null };
    if (existingIdx >= 0) {
      nextRows[existingIdx] = nextRow;
    } else {
      nextRows.push(nextRow);
    }
    const rows = await persistOwnershipSet({
      clientId: client,
      ownedId: toId,
      rows: nextRows,
      asOfDate,
      changedBy: req.auth.loginId,
    });
    const saved = rows.find((r) => r.from === fromId && r.to === toId) || rows[0];
    res.json(toRelResponse(saved));
  } catch (err) {
    console.error("/api/relationships/owns error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.put("/api/relationships/owns", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { from, to, percent, asOfDate } = req.body || {};
    if (!from || !to) {
      return res.status(400).json({ error: "from and to are required" });
    }
    const fromId = normalizeClientId(client, from);
    const toId = normalizeClientId(client, to);
    const allCurrent = await queryOwnershipCurrent(client);
    const currentForOwned = allCurrent.filter((r) => r.type === "owns" && r.to === toId);
    const existingIdx = currentForOwned.findIndex((r) => r.from === fromId);
    if (existingIdx < 0) return res.status(404).json({ error: "relationship not found" });
    const nextRows = currentForOwned.map((r) => ({ from: r.from, to: toId, percent: r.percent }));
    nextRows[existingIdx] = { from: fromId, to: toId, percent: percent ?? null };
    const rows = await persistOwnershipSet({
      clientId: client,
      ownedId: toId,
      rows: nextRows,
      asOfDate,
      changedBy: req.auth.loginId,
    });
    const saved = rows.find((r) => r.from === fromId && r.to === toId) || rows[0];
    res.json(toRelResponse(saved));
  } catch (err) {
    console.error("/api/relationships/owns (put) error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.delete("/api/relationships/owns", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { from, to, asOfDate } = req.body || {};
    if (!from || !to) {
      return res.status(400).json({ error: "from and to are required" });
    }
    const fromId = normalizeClientId(client, from);
    const toId = normalizeClientId(client, to);
    const allCurrent = await queryOwnershipCurrent(client);
    const currentForOwned = allCurrent.filter((r) => r.type === "owns" && r.to === toId);
    const nextRows = currentForOwned
      .filter((r) => r.from !== fromId)
      .map((r) => ({ from: r.from, to: toId, percent: r.percent }));
    await persistOwnershipSet({
      clientId: client,
      ownedId: toId,
      rows: nextRows,
      asOfDate,
      changedBy: req.auth.loginId,
    });
    res.json({ from: fromId, to: toId });
  } catch (err) {
    console.error("/api/relationships/owns (delete) error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// ─── Fetch version history for a node ──────────────────────────────────────
// Name index for duplicate-name warnings: every node (including deleted ones that still
// have history) with its current name and each name it has had, with date ranges.
app.get("/api/node-names", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const byId = new Map();
    const ensure = (id) => {
      if (!byId.has(id)) byId.set(id, { id, kind: null, currentName: null, deleted: true, names: [] });
      return byId.get(id);
    };
    // History is consumed page by page; only the small per-name entries are retained.
    const [currentNodes] = await Promise.all([
      queryNodes(client),
      forEachNodeHistoryPage(client, (page) => {
        page.forEach((row) => {
          const id = row.id || row.nodeId;
          if (!id || !row.name) return;
          const entry = ensure(id);
          if (!entry.kind) entry.kind = row.kind || null;
          entry.names.push({
            name: row.name,
            kind: row.kind || null,
            effectiveFrom: row.effectiveFrom || null,
            effectiveTo: row.effectiveTo || null,
          });
        });
      }),
    ]);
    currentNodes.forEach((node) => {
      const id = node.id || node.nodeId;
      if (!id) return;
      const entry = ensure(id);
      entry.kind = node.kind || null;
      entry.currentName = node.name || null;
      entry.deleted = false;
    });
    byId.forEach((entry) => {
      entry.names.sort((a, b) => (a.effectiveFrom || "").localeCompare(b.effectiveFrom || ""));
    });
    res.json({ nodes: [...byId.values()] });
  } catch (err) {
    console.error("/api/node-names error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Returns every EMPlusNodeHistory version for the node, oldest first. effectiveTo is
// exclusive (the version applies while effectiveFrom <= date < effectiveTo).
app.get("/api/nodes/:id/history", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const nodeId = normalizeClientId(client, req.params.id);
    const historyRows = await queryNodeHistoryForNode(client, nodeId);
    const rows = historyRows
      .filter((row) => row.nodeId === nodeId)
      .sort((a, b) =>
        (a.effectiveFrom || "0001-01-01").localeCompare(b.effectiveFrom || "0001-01-01")
        || String(a.changedAt || "").localeCompare(String(b.changedAt || ""))
      );

    // changedBy is a loginId; resolve it to the linked person's name when possible.
    const loginIds = [...new Set(rows.map((r) => r.changedBy).filter(Boolean))];
    const nameByLogin = new Map();
    await Promise.all(loginIds.map(async (loginId) => {
      try {
        const user = await getUser(loginId);
        if (!user || user.clientId !== client || !user.personId) return;
        const person = await getNode(client, normalizeClientId(client, user.personId));
        if (person?.name) nameByLogin.set(loginId, person.name);
      } catch {
        // fall back to the loginId
      }
    }));

    const versions = rows.map((row) => ({
      ...toNodeResponse(row),
      versionId: row.versionId || row.nodeHistoryKey,
      effectiveFrom: row.effectiveFrom || null,
      effectiveTo: row.effectiveTo || null,
      changedAt: row.changedAt || null,
      changedBy: row.changedBy || null,
      changedByName: row.changedBy ? (nameByLogin.get(row.changedBy) || row.changedBy) : null,
    }));
    res.json({ nodeId, versions });
  } catch (err) {
    console.error("/api/nodes/:id/history error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// ─── Fetch ownership history timeline for an entity ────────────────────────

app.get("/api/ownership/history/:entityId", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const entityId = req.params.entityId;
    const toId = normalizeClientId(client, entityId);

    // Only query EMPlusOwnershipHistory — persistOwnershipSet always writes every period
    // to history (via batchPutOwnershipHistory), so history is the single source of truth
    // for all periods including the current one. Querying current as well would double-count.
    const historyRows = await queryOwnershipHistory(client);
    const historyForEntity = historyRows.filter((r) => r.type === "owns" && r.to === toId);

    // Group records by setId to get distinct ownership periods
    const periodsBySetId = new Map();

    historyForEntity.forEach((row) => {
      if (!row.setId) return;
      if (!periodsBySetId.has(row.setId)) {
        periodsBySetId.set(row.setId, {
          setId: row.setId,
          effectiveFrom: row.effectiveFrom || "0001-01-01",
          owners: [],
          changedAt: row.changedAt || null,
          changedBy: row.changedBy || null,
        });
      }
      periodsBySetId.get(row.setId).owners.push({
        from: row.from,
        percent: row.percent,
      });
    });

    // Convert to array and sort by effectiveFrom (oldest first for computing effectiveTo)
    let periods = Array.from(periodsBySetId.values()).sort((a, b) => {
      const aDate = a.effectiveFrom || "0001-01-01";
      const bDate = b.effectiveFrom || "0001-01-01";
      return aDate.localeCompare(bDate); // oldest first
    });

    // Compute effectiveTo for each period (= next period's effectiveFrom - 1 day)
    // effectiveTo is not stored — derived from adjacent periods to prevent gaps
    periods = periods.map((period, index) => {
      if (index < periods.length - 1) {
        // Not the last period: effectiveTo = next period's effectiveFrom - 1 day
        const nextPeriodStart = periods[index + 1].effectiveFrom;
        const nextDate = new Date(nextPeriodStart + 'T00:00:00Z');
        nextDate.setUTCDate(nextDate.getUTCDate() - 1);
        const year = nextDate.getUTCFullYear();
        const month = String(nextDate.getUTCMonth() + 1).padStart(2, '0');
        const day = String(nextDate.getUTCDate()).padStart(2, '0');
        period.effectiveTo = `${year}-${month}-${day}`;
      } else {
        // Last period: no end date (ongoing)
        period.effectiveTo = null;
      }
      // Remove the stored effectiveTo since we computed it
      return period;
    });

    // Sort back to newest first for display
    periods = periods.sort((a, b) => {
      const aDate = a.effectiveFrom || "0001-01-01";
      const bDate = b.effectiveFrom || "0001-01-01";
      return bDate.localeCompare(aDate);
    });

    res.json({
      entityId: toId,
      periods,
    });
  } catch (err) {
    console.error("/api/ownership/history/:entityId error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.put("/api/ownership/update-period", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { to, setId, newEffectiveFrom, owners } = req.body || {};
    
    if (!to || !setId || !newEffectiveFrom) {
      return res.status(400).json({ error: "to, setId, and newEffectiveFrom are required" });
    }
    
    const toId = normalizeClientId(client, to);
    const newFromDate = normalizeDateInput(newEffectiveFrom);
    
    if (!newFromDate) {
      return res.status(400).json({ error: "Invalid newEffectiveFrom date" });
    }

    // Fetch current records for this entity
    const currentRows = await queryOwnershipCurrent(client);
    const entityRecords = currentRows.filter((r) => r.type === "owns" && r.to === toId && r.setId === setId);
    
    if (entityRecords.length === 0) {
      return res.status(404).json({ error: "Ownership group not found" });
    }

    // Same effectiveFrom means "replace that dated set" (mirrors persistOwnershipSet):
    // if another period for this entity already starts on newFromDate, delete it first
    // so moving this period onto that date can't leave two periods with the same start.
    const collidingCurrent = currentRows.filter(
      (r) => r.type === "owns" && r.to === toId && r.setId !== setId
        && normalizeDateInput(r.effectiveFrom) === newFromDate
    );
    await Promise.all(collidingCurrent.map((r) => deleteOwnershipCurrent(client, r.ownershipKey)));

    const allHistoryForCollision = await queryOwnershipHistory(client);
    const collidingHistory = allHistoryForCollision.filter(
      (r) => r.type === "owns" && r.to === toId && r.setId !== setId
        && normalizeDateInput(r.effectiveFrom) === newFromDate
    );
    await Promise.all(collidingHistory.map((r) => deleteOwnershipHistory(client, r.ownershipHistoryKey)));

    // Delete old records with this setId in current table
    for (const record of entityRecords) {
      await deleteOwnershipCurrent(client, record.ownershipKey);
    }

    // Create updated records with new effectiveFrom only
    // effectiveTo is computed on-the-fly from the next period's effectiveFrom
    if (owners && Array.isArray(owners)) {
      for (const owner of owners) {
        const from = normalizeClientId(client, owner.from);
        const newRecord = {
          clientId: client,
          ownershipKey: makeOwnershipCurrentKey(from, toId),
          type: "owns",
          to: toId,
          from,
          percent: owner.percent,
          setId: setId,
          effectiveFrom: newFromDate,
          // Do NOT store effectiveTo - it will be computed from next period
          changedAt: new Date().toISOString(),
          changedBy: req.auth.loginId,
        };
        await putOwnershipCurrent(newRecord);
      }
    } else {
      // Keep existing owners if not provided
      for (const record of entityRecords) {
        const updatedRecord = { 
          ...record, 
          effectiveFrom: newFromDate,
          // Remove stored effectiveTo since we'll compute it
        };
        delete updatedRecord.effectiveTo;
        await putOwnershipCurrent(updatedRecord);
      }
    }

    // Update all records with this setId in history table to match the new date
    const historyRows = await queryOwnershipHistory(client);
    const historyRecords = historyRows.filter((r) => r.type === "owns" && r.to === toId && r.setId === setId);
    for (const record of historyRecords) {
      await deleteOwnershipHistory(client, record.ownershipHistoryKey);
      const updatedRecord = { ...record, effectiveFrom: newFromDate };
      // Remove stored effectiveTo since we'll compute it
      delete updatedRecord.effectiveTo;
      await putOwnershipHistory(updatedRecord);
    }

    res.json({ setId, newEffectiveFrom: newFromDate });
  } catch (err) {
    console.error("/api/ownership/update-period error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// ─── Delete an ownership group by setId ────────────────────────────────────────

app.delete("/api/ownership/group/:entityId/:setId", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const entityId = req.params.entityId;
    const setId = req.params.setId;
    
    if (!entityId || !setId) {
      return res.status(400).json({ error: "entityId and setId are required" });
    }
    
    const toId = normalizeClientId(client, entityId);

    // Fetch and delete from both tables — a period may exist only in history (non-current)
    const [currentRows, historyRows] = await Promise.all([
      queryOwnershipCurrent(client),
      queryOwnershipHistory(client),
    ]);

    const currentRecords = currentRows.filter((r) => r.type === "owns" && r.to === toId && r.setId === setId);
    const historyRecords = historyRows.filter((r) => r.type === "owns" && r.to === toId && r.setId === setId);

    if (currentRecords.length === 0 && historyRecords.length === 0) {
      return res.status(404).json({ error: "Ownership group not found" });
    }

    for (const record of currentRecords) {
      await deleteOwnershipCurrent(client, record.ownershipKey);
    }

    for (const record of historyRecords) {
      await deleteOwnershipHistory(client, record.ownershipHistoryKey);
    }

    res.json({ setId, deleted: true });
  } catch (err) {
    console.error("/api/ownership/group/:entityId/:setId error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.put("/api/ownership/sets", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { to, owners, asOfDate } = req.body || {};
    if (!to || !Array.isArray(owners) || owners.length === 0) {
      return res.status(400).json({ error: "to and owners[] are required" });
    }
    const toId = normalizeClientId(client, to);
    const rows = owners.map((owner) => ({
      from: normalizeClientId(client, owner.from),
      to: toId,
      percent: owner.percent,
    }));
    const saved = await persistOwnershipSet({
      clientId: client,
      ownedId: toId,
      rows,
      asOfDate,
      changedBy: req.auth.loginId,
    });
    res.json({ to: toId, rows: saved.map(toRelResponse) });
  } catch (err) {
    console.error("/api/ownership/sets error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// ─── EMPLOYS ──────────────────────────────────────────────────────────────────

app.post("/api/relationships/employs", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { from, to, role, startDate, endDate } = req.body || {};
    if (!from || !to) {
      return res.status(400).json({ error: "from and to are required" });
    }
    const fromId = normalizeClientId(client, from);
    const toId = normalizeClientId(client, to);
    const relKey = makeRelKey("employs", fromId, toId);
    const now = new Date().toISOString();
    const existing = await getRel(client, relKey);
    const item = buildEmploysItem({
      from: fromId, to: toId, role: role || null,
      startDate: startDate || null, endDate: endDate || null, client,
      createdAt: existing?.createdAt || now, updatedAt: now,
    });
    await putRel(item);
    res.json(toRelResponse(item));
  } catch (err) {
    console.error("/api/relationships/employs error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.put("/api/relationships/employs", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { from, to, role, startDate, endDate } = req.body || {};
    if (!from || !to) {
      return res.status(400).json({ error: "from and to are required" });
    }
    const fromId = normalizeClientId(client, from);
    const toId = normalizeClientId(client, to);
    const relKey = makeRelKey("employs", fromId, toId);
    const existing = await getRel(client, relKey);
    if (!existing) return res.status(404).json({ error: "relationship not found" });
    const item = buildEmploysItem({
      from: fromId, to: toId, role: role || null,
      startDate: startDate || null, endDate: endDate || null, client,
      createdAt: existing.createdAt, updatedAt: new Date().toISOString(),
    });
    await putRel(item);
    res.json(toRelResponse(item));
  } catch (err) {
    console.error("/api/relationships/employs (put) error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

app.delete("/api/relationships/employs", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { from, to } = req.body || {};
    if (!from || !to) {
      return res.status(400).json({ error: "from and to are required" });
    }
    const fromId = normalizeClientId(client, from);
    const toId = normalizeClientId(client, to);
    await deleteRel(client, makeRelKey("employs", fromId, toId));
    res.json({ from: fromId, to: toId });
  } catch (err) {
    console.error("/api/relationships/employs (delete) error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// ─── FILE UPLOAD ──────────────────────────────────────────────────────────────

// POST /api/upload — upload a file to S3 as a public-read object and return its
// permanent public URL.  The object key contains 32 random hex chars so the URL
// is not guessable.  Requires S3_BUCKET_UPLOADS env var; returns 501 if not set.
//
// Bucket prerequisites (set once in the AWS console or via CLI):
//   • "Block all public access" → OFF
//   • Bucket policy granting s3:GetObject on arn:aws:s3:::BUCKET/uploads/*
app.post("/api/upload", upload.single("file"), async (req, res) => {
  try {
    if (!s3 || !S3_BUCKET) {
      return res.status(501).json({ error: "File upload not configured (set S3_BUCKET_UPLOADS env var)" });
    }
    if (!req.file?.buffer) return res.status(400).json({ error: "file is required" });

    // Derive a safe extension from the original file name.
    const original = req.file.originalname || "upload";
    const ext = original.includes(".")
      ? original.split(".").pop().replace(/[^a-zA-Z0-9]/g, "").toLowerCase().slice(0, 10)
      : "bin";
    const key = `uploads/${req.auth.clientId}/${randomBytes(16).toString("hex")}.${ext}`;
    const region = process.env.AWS_REGION || "us-east-1";

    // Derive content type — prefer multer's detection but fall back by extension
    const MIME_BY_EXT = { jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", gif: "image/gif", webp: "image/webp", pdf: "application/pdf" };
    const contentType = (req.file.mimetype && req.file.mimetype !== "application/octet-stream")
      ? req.file.mimetype
      : (MIME_BY_EXT[ext] || "application/octet-stream");

    await s3.send(
      new PutObjectCommand({
        Bucket: S3_BUCKET,
        Key: key,
        Body: req.file.buffer,
        ContentType: contentType,
      })
    );

    // Permanent public URL — never expires.
    const url = `https://${S3_BUCKET}.s3.${region}.amazonaws.com/${key}`;
    res.json({ url, key });
  } catch (err) {
    console.error("/api/upload error", err);
    res.status(500).json({ error: err.message });
  }
});

// ─── IMAGE PROXY ─────────────────────────────────────────────────────────────

// GET /api/proxy-image?url=<encoded-s3-url>
// Fetches a file from our own S3 bucket server-side and returns it to the
// client.  This lets html2canvas render cross-origin S3 images without needing
// a CORS policy on the bucket.  Only URLs that start with our configured bucket
// hostname are allowed to prevent open-proxy abuse.
app.get("/api/proxy-image", async (req, res) => {
  try {
    const { url } = req.query;
    if (!url) return res.status(400).json({ error: "url is required" });

    if (!S3_BUCKET || !url.startsWith(`https://${S3_BUCKET}.s3.`)) {
      return res.status(403).json({ error: "URL not permitted" });
    }

    const upstream = await fetch(url);
    if (!upstream.ok) return res.status(upstream.status).json({ error: "Upstream error" });

    const buffer = await upstream.arrayBuffer();
    const upstreamType = upstream.headers.get("content-type") || "";
    const ext = url.split(".").pop().split("?")[0].toLowerCase();
    const MIME_BY_EXT = { jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", gif: "image/gif", webp: "image/webp" };
    const mimeType = upstreamType.startsWith("image/") ? upstreamType : (MIME_BY_EXT[ext] || "image/jpeg");
    const b64 = Buffer.from(buffer).toString("base64");
    const dataUrl = `data:${mimeType};base64,${b64}`;

    // Return as JSON — avoids API Gateway binary encoding issues entirely
    res.json({ dataUrl });
  } catch (err) {
    console.error("/api/proxy-image error", err);
    res.status(500).json({ error: err.message });
  }
});

// ─── DATA DICTIONARY ──────────────────────────────────────────────────────────

const VALID_DATA_TYPES = new Set([
  "string", "textarea", "number", "currency", "percentage",
  "boolean", "date", "time", "phone", "email", "link", "file", "address", "year",
]);

const VALID_APPLIES_TO = new Set(["entity", "person", "both", "ownership", "entity,ownership", "person,ownership", "entity,person,ownership"]);
// Accept arrays by serializing them to a canonical string
function serializeAppliesTo(v) {
  if (Array.isArray(v)) {
    const vals = [...new Set(v)].filter((s) => ["entity", "person", "ownership"].includes(s)).sort();
    if (!vals.length) return "both";
    if (vals.length === 1) return vals[0];
    if (vals.join(",") === "entity,person") return "both";
    return vals.join(",");
  }
  return v;
}

const toDDResponse = ({ clientId: _c, ...rest }) => rest;

// GET /api/data-dictionary?client=<clientId>
app.get("/api/data-dictionary", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const items = await queryDDFields(client);
    res.json(items.map(toDDResponse));
  } catch (err) {
    console.error("/api/data-dictionary GET error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// POST /api/data-dictionary
app.post("/api/data-dictionary", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { prompt, dataType, multiValue, validValues, phoneTypes, showInStats } = req.body || {};
    const appliesTo = serializeAppliesTo(req.body?.appliesTo);
    if (!prompt || !prompt.trim()) {
      return res.status(400).json({ error: "prompt is required" });
    }
    if (!VALID_DATA_TYPES.has(dataType)) {
      return res.status(400).json({ error: `invalid dataType: ${dataType}` });
    }
    if (!VALID_APPLIES_TO.has(appliesTo)) {
      return res.status(400).json({ error: `invalid appliesTo: ${appliesTo}` });
    }
    const fieldId = `dd:${slugify(prompt.trim())}-${Date.now().toString(36)}`;
    const now = new Date().toISOString();
    const existingFields = await queryDDFields(client);
    const item = {
      clientId: client,
      fieldId,
      id: fieldId,
      prompt: prompt.trim(),
      dataType,
      appliesTo: appliesTo || "both",
      multiValue: !!multiValue,
      validValues: Array.isArray(validValues) ? validValues.filter(Boolean) : [],
      phoneTypes: Array.isArray(phoneTypes) ? phoneTypes.filter(Boolean) : [],
      showInStats: !!showInStats,
      sortOrder: existingFields.length,
      createdAt: now,
      updatedAt: now,
    };
    await putDDField(item);
    res.status(201).json(toDDResponse(item));
  } catch (err) {
    console.error("/api/data-dictionary POST error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// PUT /api/data-dictionary/:fieldId
app.put("/api/data-dictionary/:fieldId", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const fieldId = req.params.fieldId;
    const { prompt, dataType, multiValue, validValues, phoneTypes, showInStats } = req.body || {};
    const appliesTo = serializeAppliesTo(req.body?.appliesTo);
    if (!prompt || !prompt.trim()) {
      return res.status(400).json({ error: "prompt is required" });
    }
    if (!VALID_DATA_TYPES.has(dataType)) {
      return res.status(400).json({ error: `invalid dataType: ${dataType}` });
    }
    if (!VALID_APPLIES_TO.has(appliesTo)) {
      return res.status(400).json({ error: `invalid appliesTo: ${appliesTo}` });
    }
    const existing = await getDDField(client, fieldId);
    if (!existing) return res.status(404).json({ error: "field not found" });
    const item = {
      ...existing,
      prompt: prompt.trim(),
      dataType,
      appliesTo: appliesTo || "both",
      multiValue: !!multiValue,
      validValues: Array.isArray(validValues) ? validValues.filter(Boolean) : [],
      phoneTypes: Array.isArray(phoneTypes) ? phoneTypes.filter(Boolean) : [],
      showInStats: !!showInStats,
      updatedAt: new Date().toISOString(),
    };
    await putDDField(item);
    res.json(toDDResponse(item));
  } catch (err) {
    console.error("/api/data-dictionary PUT error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// DELETE /api/data-dictionary/:fieldId
app.delete("/api/data-dictionary/:fieldId", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const fieldId = req.params.fieldId;
    const existing = await getDDField(client, fieldId);
    if (!existing) return res.status(404).json({ error: "field not found" });
    await deleteDDField(client, fieldId);
    res.json({ fieldId });
  } catch (err) {
    console.error("/api/data-dictionary DELETE error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// PUT /api/data-dictionary/:fieldId/reorder
app.put("/api/data-dictionary/:fieldId/reorder", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { fieldId } = req.params;
    const { direction } = req.body || {};
    if (direction !== "up" && direction !== "down") {
      return res.status(400).json({ error: "direction must be 'up' or 'down'" });
    }
    const all = await queryDDFields(client);
    // Normalize to consecutive integers so the swap is always predictable,
    // even for legacy entries created before sortOrder was introduced.
    const sorted = [...all]
      .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0))
      .map((f, i) => ({ ...f, sortOrder: i }));
    const idx = sorted.findIndex((f) => f.fieldId === fieldId);
    if (idx === -1) return res.status(404).json({ error: "field not found" });
    const swapIdx = direction === "up" ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= sorted.length) {
      return res.status(400).json({ error: "cannot move in that direction" });
    }
    const now = new Date().toISOString();
    // Apply the swap and persist every item so all sortOrders are normalized.
    const toSave = sorted.map((f, i) => {
      if (i === idx) return { ...f, sortOrder: swapIdx, updatedAt: now };
      if (i === swapIdx) return { ...f, sortOrder: idx, updatedAt: now };
      return f;
    });
    await Promise.all(toSave.map((f) => putDDField(f)));
    res.json(toSave.map(toDDResponse));
  } catch (err) {
    console.error("/api/data-dictionary reorder error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// ─── EXPORT REPORTS ───────────────────────────────────────────────────────────

const toExportReportResponse = ({ clientId: _c, ...rest }) => rest;

const slugifyReportName = (name) =>
  String(name || "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "") || "report";

// GET /api/export-reports — list all saved export reports for this client
app.get("/api/export-reports", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const items = await queryExportReports(client);
    res.json(items.map(toExportReportResponse));
  } catch (err) {
    console.error("/api/export-reports GET error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// PUT /api/export-reports/:reportId — upsert (create or overwrite by name-slug key)
app.put("/api/export-reports/:reportId", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { reportId } = req.params;
    const { name, fieldIds } = req.body || {};
    if (!name || !name.trim()) {
      return res.status(400).json({ error: "name is required" });
    }
    if (!Array.isArray(fieldIds)) {
      return res.status(400).json({ error: "fieldIds must be an array" });
    }
    const now = new Date().toISOString();
    const existing = await getExportReport(client, reportId);
    const item = {
      clientId: client,
      reportId,
      id: reportId,
      name: name.trim(),
      fieldIds,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
    await putExportReport(item);
    res.json(toExportReportResponse(item));
  } catch (err) {
    console.error("/api/export-reports PUT error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// DELETE /api/export-reports/:reportId
app.delete("/api/export-reports/:reportId", async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { reportId } = req.params;
    const existing = await getExportReport(client, reportId);
    if (!existing) return res.status(404).json({ error: "report not found" });
    await deleteExportReport(client, reportId);
    res.json({ reportId });
  } catch (err) {
    console.error("/api/export-reports DELETE error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// GET /api/auth/me — return the current user's profile (no password hash).
// Also includes clientName from the client record so all users can display it.
app.get("/api/auth/me", async (req, res) => {
  try {
    const user = await getUser(req.auth.loginId);
    if (!user) return res.status(404).json({ error: "User not found" });
    const { passwordHash, ...profile } = user;
    // Attach clientName so the UI can use it without a separate admin-only request
    const clientRecord = await getClient(req.auth.clientId).catch(() => null);
    if (clientRecord?.clientName) profile.clientName = clientRecord.clientName;
    res.json(profile);
  } catch (err) {
    console.error("/api/auth/me GET error", err);
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/auth/me — update editable profile fields.
app.patch("/api/auth/me", async (req, res) => {
  try {
    const user = await getUser(req.auth.loginId);
    if (!user) return res.status(404).json({ error: "User not found" });
    const { name, email, cellPhone, workPhone, homeScreen, tabularViews, tabularViewsSelectedId } = req.body || {};
    const normalizedTabularViews = Array.isArray(tabularViews)
      ? tabularViews.map((view) => {
          if (!view || typeof view !== "object") return null;
          const { hidden, ...rest } = view;
          return rest;
        }).filter(Boolean)
      : tabularViews;
    const updated = {
      ...user,
      ...(name       !== undefined && { name:       String(name).trim() }),
      ...(email      !== undefined && { email:      String(email).trim() }),
      ...(cellPhone  !== undefined && { cellPhone:  String(cellPhone).trim() }),
      ...(workPhone  !== undefined && { workPhone:  String(workPhone).trim() }),
      ...(homeScreen !== undefined && { homeScreen: homeScreen }),
      ...(tabularViews !== undefined && { tabularViews: normalizedTabularViews }),
      ...(tabularViewsSelectedId !== undefined && { tabularViewsSelectedId: tabularViewsSelectedId }),
    };
    await putUser(updated);
    const { passwordHash, ...profile } = updated;
    res.json(profile);
  } catch (err) {
    console.error("/api/auth/me PATCH error", err);
    res.status(500).json({ error: err.message });
  }
});

// POST /api/auth/users — add a user to the currently authenticated client.
// JWT required; admin role required; new user is scoped to req.auth.clientId.
app.post("/api/auth/users", requireAdmin, async (req, res) => {
  try {
    const client = req.auth.clientId;
    const { loginId, password, personId, role } = req.body || {};
    if (!loginId || !password) {
      return res.status(400).json({ error: "loginId and password are required" });
    }
    const normalizedId = String(loginId).toLowerCase().trim();
    const existing = await getUser(normalizedId);
    if (existing) return res.status(409).json({ error: "loginId already exists" });
    const passwordHash = await bcrypt.hash(password, 10);
    const newRole = role === "admin" ? "admin" : "user";
    const user = {
      loginId: normalizedId,
      clientId: client,
      personId: personId || null,
      role: newRole,
      passwordHash,
      createdAt: new Date().toISOString(),
    };
    await putUser(user);
    res.status(201).json({ loginId: user.loginId, clientId: user.clientId, role: user.role });
  } catch (err) {
    console.error("/api/auth/users error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// GET /api/auth/users — list all users for this client (admin only).
app.get("/api/auth/users", requireAdmin, async (req, res) => {
  try {
    const users = await listUsersByClient(req.auth.clientId);
    const response = users.map(({ passwordHash: _, ...u }) => u);
    res.json(response);
  } catch (err) {
    console.error("/api/auth/users GET error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// PATCH /api/auth/users/:loginId — change a user's role (admin only).
// Only users belonging to req.auth.clientId may be updated.
app.patch("/api/auth/users/:loginId", requireAdmin, async (req, res) => {
  try {
    const client = req.auth.clientId;
    const targetId = String(req.params.loginId).toLowerCase().trim();
    const { role } = req.body || {};
    if (role !== "admin" && role !== "user") {
      return res.status(400).json({ error: "role must be \"admin\" or \"user\"" });
    }
    const user = await getUser(targetId);
    if (!user) return res.status(404).json({ error: "User not found" });
    if (user.clientId !== client) return res.status(403).json({ error: "User belongs to a different client" });
    await putUser({ ...user, role });
    res.json({ loginId: user.loginId, clientId: user.clientId, role });
  } catch (err) {
    console.error("/api/auth/users/:loginId PATCH error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// ─── CLIENT INFO ──────────────────────────────────────────────────────────────

// GET /api/client — return this client's info record (admin only).
app.get("/api/client", requireAdmin, async (req, res) => {
  try {
    const clientId = req.auth.clientId;
    const record = await getClient(clientId);
    if (!record) return res.json({});
    const { clientId: _c, ...response } = record;
    res.json(response);
  } catch (err) {
    console.error("/api/client GET error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// PATCH /api/client — create or update this client's info record (admin only).
app.patch("/api/client", requireAdmin, async (req, res) => {
  try {
    const clientId = req.auth.clientId;
    const { clientName, address, billingContact, billingEmail, billingPhone, notes } = req.body || {};
    const existing = await getClient(clientId);
    const now = new Date().toISOString();
    const updated = {
      clientId,
      ...(existing || { createdAt: now }),
      ...(clientName     !== undefined && { clientName:     String(clientName).trim() }),
      ...(address        !== undefined && { address:        String(address).trim() }),
      ...(billingContact !== undefined && { billingContact: String(billingContact).trim() }),
      ...(billingEmail   !== undefined && { billingEmail:   String(billingEmail).trim() }),
      ...(billingPhone   !== undefined && { billingPhone:   String(billingPhone).trim() }),
      ...(notes          !== undefined && { notes:          String(notes).trim() }),
      updatedAt: now,
    };
    await putClient(updated);
    const { clientId: _c, ...response } = updated;
    res.json(response);
  } catch (err) {
    console.error("/api/client PATCH error", err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

// ─── CLONE CLIENT ─────────────────────────────────────────────────────────────

// POST /api/admin/clone-client — admin-only; creates a new empty client with:
//   • a new client record (EMPlusClients)
//   • a single admin user whose loginId is  <first segment of caller's loginId>-<newClientId>
//     and whose password hash is copied from the caller (same password, no plaintext needed)
//   • a full copy of the source client's DataDictionary
// The new client starts with no nodes/rels — the new admin is expected to import data.
app.post("/api/admin/clone-client", requireAdmin, async (req, res) => {
  try {
    const srcClientId = req.auth.clientId;
    const { newClientId } = req.body || {};

    if (!newClientId || !String(newClientId).trim()) {
      return res.status(400).json({ error: "newClientId is required" });
    }

    // Normalise to lowercase slug (same chars allowed as clientId throughout the app).
    const cleanId = String(newClientId)
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, "-")
      .replace(/(^-|-$)/g, "");

    if (!cleanId) {
      return res.status(400).json({ error: "newClientId must contain alphanumeric characters" });
    }

    // Guard: reject if the target client already has users.
    const existingCount = await countUsersByClient(cleanId);
    if (existingCount > 0) {
      return res.status(409).json({ error: `Client "${cleanId}" already exists` });
    }

    // Fetch the current admin's record so we can copy the password hash.
    const srcUser = await getUser(req.auth.loginId);
    if (!srcUser) return res.status(404).json({ error: "Source user not found" });

    // New admin loginId: first "-"-delimited segment of current loginId + "-" + newClientId.
    const baseLoginId = req.auth.loginId.split("-")[0];
    const newLoginId = `${baseLoginId}-${cleanId}`;

    // Guard: loginId must not already exist in the users table.
    const existingLogin = await getUser(newLoginId);
    if (existingLogin) {
      return res.status(409).json({ error: `Login ID "${newLoginId}" is already taken` });
    }

    const now = new Date().toISOString();

    // 1. Create the new client record.
    await putClient({
      clientId: cleanId,
      clonedFrom: srcClientId,
      createdAt: now,
      updatedAt: now,
    });

    // 2. Create the new admin user, reusing the source user's bcrypt hash so the
    //    new admin can log in with the same password without us ever seeing it as
    //    plaintext.
    await putUser({
      loginId: newLoginId,
      clientId: cleanId,
      personId: null,
      role: "admin",
      passwordHash: srcUser.passwordHash,
      createdAt: now,
    });

    // 3. Copy all DataDictionary fields from the source client to the new client.
    const ddFields = await queryDDFields(srcClientId);
    if (ddFields.length > 0) {
      await Promise.all(
        ddFields.map((field) =>
          putDDField({ ...field, clientId: cleanId, updatedAt: now })
        )
      );
    }

    res.status(201).json({
      ok: true,
      newClientId: cleanId,
      newLoginId,
      ddFieldsCloned: ddFields.length,
    });
  } catch (err) {
    console.error("/api/admin/clone-client error", err);
    res.status(500).json({ error: err.message });
  }
});

export default app;
